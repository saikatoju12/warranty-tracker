import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:warranty_tracker/app/router/app_router.dart';
import 'package:warranty_tracker/app/theme/app_theme.dart';
import 'package:warranty_tracker/auth/presentation/bloc/auth_bloc.dart';
import 'package:warranty_tracker/core/di/injection_container.dart';
import 'package:warranty_tracker/core/services/premium_service.dart';
import 'package:warranty_tracker/notifications/presentation/bloc/notification_bloc.dart';
import 'package:warranty_tracker/warranty/presentation/bloc/warranty_bloc.dart';

class WarrantyTrackerApp extends StatelessWidget {
  const WarrantyTrackerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => sl<AuthBloc>()..add(AuthStarted()),
        ),
        BlocProvider(
          create: (context) => sl<WarrantyBloc>(),
        ),
        BlocProvider(
          create: (context) => sl<NotificationBloc>()..add(LoadNotifications()),
        ),
      ],
      child: MaterialApp.router(
        title: 'Warranty Tracker',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.system,
        routerConfig: AppRouter.router,
        builder: (context, child) {
          return MediaQuery(
            data: MediaQuery.of(context).copyWith(
              textScaleFactor: 1.0, // Prevent text scaling issues
            ),
            child: child!,
          );
        },
      ),
    );
  }
}