import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:warranty_tracker/app/router/app_router.dart';
import 'package:warranty_tracker/core/constants/app_constants.dart';
import 'package:warranty_tracker/premium/presentation/bloc/premium_bloc.dart';
import 'package:warranty_tracker/premium/presentation/widgets/premium_feature_card.dart';
import 'package:warranty_tracker/premium/presentation/widgets/pricing_card.dart';

class PremiumPage extends StatelessWidget {
  const PremiumPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Go Premium'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hero section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Theme.of(context).colorScheme.primary,
                    Theme.of(context).colorScheme.primaryContainer,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  Icon(
                    Icons.diamond,
                    size: 64,
                    color: Theme.of(context).colorScheme.onPrimary,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Unlock Premium Features',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          color: Theme.of(context).colorScheme.onPrimary,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'One-time purchase, lifetime access',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context).colorScheme.onPrimary.withOpacity(0.8),
                        ),
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 32),
            
            // Features comparison
            Text(
              'What you get with Premium',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 16),
            
            const PremiumFeatureCard(
              icon: Icons.document_scanner,
              title: 'Advanced OCR',
              description: 'Extract warranty details automatically from receipts',
              isPremium: true,
            ),
            
            const PremiumFeatureCard(
              icon: Icons.email,
              title: 'Email Receipt Scanning',
              description: 'Automatically scan email receipts for new warranties',
              isPremium: true,
            ),
            
            const PremiumFeatureCard(
              icon: Icons.cloud_upload,
              title: 'Unlimited Storage',
              description: 'Store unlimited warranties and receipts',
              isPremium: true,
            ),
            
            const PremiumFeatureCard(
              icon: Icons.people,
              title: 'Multiple Profiles',
              description: 'Share warranties with family members',
              isPremium: true,
            ),
            
            const PremiumFeatureCard(
              icon: Icons.picture_as_pdf,
              title: 'Export to PDF',
              description: 'Export your warranties as PDF documents',
              isPremium: true,
            ),
            
            const PremiumFeatureCard(
              icon: Icons.block,
              title: 'No Ads',
              description: 'Enjoy a completely ad-free experience',
              isPremium: true,
            ),
            
            const SizedBox(height: 32),
            
            // Pricing
            PricingCard(
              price: AppConstants.premiumPrice,
              currency: AppConstants.premiumCurrency,
              features: [
                'All premium features',
                'Lifetime access',
                'One-time payment',
                '30-day money-back guarantee',
              ],
              onPurchase: () {
                _showPurchaseDialog(context);
              },
            ),
            
            const SizedBox(height: 16),
            
            // Restore purchases
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () {
                  context.read<PremiumBloc>().add(RestorePurchases());
                },
                child: const Text('Restore Purchases'),
              ),
            ),
            
            const SizedBox(height: 32),
            
            // Terms and privacy
            Center(
              child: Column(
                children: [
                  TextButton(
                    onPressed: () {
                      // TODO: Navigate to terms
                    },
                    child: const Text('Terms of Service'),
                  ),
                  TextButton(
                    onPressed: () {
                      // TODO: Navigate to privacy
                    },
                    child: const Text('Privacy Policy'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showPurchaseDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Complete Purchase'),
        content: const Text(
          'Unlock all premium features for a one-time payment of \$19.99. '
          'Your purchase is protected by our 30-day money-back guarantee.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              // TODO: Implement purchase flow
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Purchase flow coming soon!')),
              );
            },
            child: const Text('Purchase'),
          ),
        ],
      ),
    );
  }
}