import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:warranty_tracker/app/router/app_router.dart';
import 'package:warranty_tracker/core/utils/date_utils.dart';
import 'package:warranty_tracker/warranty/presentation/bloc/warranty_bloc.dart';
import 'package:warranty_tracker/warranty/presentation/widgets/warranty_card.dart';
import 'package:warranty_tracker/warranty/presentation/widgets/empty_state.dart';
import 'package:warranty_tracker/core/constants/app_constants.dart';

class WarrantyListPage extends StatelessWidget {
  const WarrantyListPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Warranties'),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              // TODO: Implement search
            },
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'sort_by_expiry':
                  context.read<WarrantyBloc>().add(SortWarrantiesByExpiry());
                  break;
                case 'sort_by_name':
                  context.read<WarrantyBloc>().add(SortWarrantiesByName());
                  break;
                case 'export':
                  // TODO: Implement export
                  break;
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'sort_by_expiry',
                child: Text('Sort by Expiry'),
              ),
              const PopupMenuItem(
                value: 'sort_by_name',
                child: Text('Sort by Name'),
              ),
              const PopupMenuItem(
                value: 'export',
                child: Text('Export'),
              ),
            ],
          ),
        ],
      ),
      body: BlocBuilder<WarrantyBloc, WarrantyState>(
        builder: (context, state) {
          if (state is WarrantyLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (state is WarrantyError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.error_outline,
                    size: 64,
                    color: Theme.of(context).colorScheme.error,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    state.message,
                    style: Theme.of(context).textTheme.bodyLarge,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {
                      context.read<WarrantyBloc>().add(LoadWarranties());
                    },
                    child: const Text('Retry'),
                  ),
                ],
              ),
            );
          }

          if (state is WarrantyLoaded) {
            if (state.warranties.isEmpty) {
              return const EmptyState();
            }

            return RefreshIndicator(
              onRefresh: () async {
                context.read<WarrantyBloc>().add(LoadWarranties());
              },
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: state.warranties.length,
                itemBuilder: (context, index) {
                  final warranty = state.warranties[index];
                  return WarrantyCard(
                    warranty: warranty,
                    onTap: () {
                      AppRouter.router.push('/warranty/${warranty.id}');
                    },
                    onEdit: () {
                      AppRouter.router.push('/warranty/${warranty.id}/edit');
                    },
                    onDelete: () {
                      _showDeleteDialog(context, warranty);
                    },
                  );
                },
              ),
            );
          }

          return const EmptyState();
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          AppRouter.router.push('/warranty/add');
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showDeleteDialog(BuildContext context, warranty) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Warranty'),
        content: Text(
          'Are you sure you want to delete ${warranty.productName} warranty?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              context.read<WarrantyBloc>().add(DeleteWarranty(warranty.id));
            },
            style: TextButton.styleFrom(
              foregroundColor: Theme.of(context).colorScheme.error,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}