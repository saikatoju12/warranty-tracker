import 'package:equatable/equatable.dart';

class WarrantyEntity extends Equatable {
  final String id;
  final String userId;
  final String productName;
  final String retailer;
  final DateTime purchaseDate;
  final DateTime expirationDate;
  final int warrantyDuration;
  final WarrantyStatus status;
  final String? notes;
  final String? serialNumber;
  final double? purchaseAmount;
  final String? receiptImageUrl;
  final OcrData? ocrData;
  final DateTime createdAt;
  final DateTime updatedAt;

  const WarrantyEntity({
    required this.id,
    required this.userId,
    required this.productName,
    required this.retailer,
    required this.purchaseDate,
    required this.expirationDate,
    required this.warrantyDuration,
    required this.status,
    this.notes,
    this.serialNumber,
    this.purchaseAmount,
    this.receiptImageUrl,
    this.ocrData,
    required this.createdAt,
    required this.updatedAt,
  });

  @override
  List<Object?> get props => [
        id,
        userId,
        productName,
        retailer,
        purchaseDate,
        expirationDate,
        warrantyDuration,
        status,
        notes,
        serialNumber,
        purchaseAmount,
        receiptImageUrl,
        ocrData,
        createdAt,
        updatedAt,
      ];

  WarrantyEntity copyWith({
    String? id,
    String? userId,
    String? productName,
    String? retailer,
    DateTime? purchaseDate,
    DateTime? expirationDate,
    int? warrantyDuration,
    WarrantyStatus? status,
    String? notes,
    String? serialNumber,
    double? purchaseAmount,
    String? receiptImageUrl,
    OcrData? ocrData,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return WarrantyEntity(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      productName: productName ?? this.productName,
      retailer: retailer ?? this.retailer,
      purchaseDate: purchaseDate ?? this.purchaseDate,
      expirationDate: expirationDate ?? this.expirationDate,
      warrantyDuration: warrantyDuration ?? this.warrantyDuration,
      status: status ?? this.status,
      notes: notes ?? this.notes,
      serialNumber: serialNumber ?? this.serialNumber,
      purchaseAmount: purchaseAmount ?? this.purchaseAmount,
      receiptImageUrl: receiptImageUrl ?? this.receiptImageUrl,
      ocrData: ocrData ?? this.ocrData,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

enum WarrantyStatus {
  active,
  expired,
  expiringSoon,
  cancelled,
}

class OcrData extends Equatable {
  final String? extractedText;
  final double confidence;
  final Map<String, dynamic>? extractedFields;

  const OcrData({
    this.extractedText,
    required this.confidence,
    this.extractedFields,
  });

  @override
  List<Object?> get props => [extractedText, confidence, extractedFields];
}