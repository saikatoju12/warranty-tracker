import 'package:intl/intl.dart';

class DateUtils {
  static const String dateFormat = 'yyyy-MM-dd';
  static const String displayDateFormat = 'MMM dd, yyyy';
  static const String dateTimeFormat = 'MMM dd, yyyy HH:mm';

  static String formatDate(DateTime date) {
    return DateFormat(dateFormat).format(date);
  }

  static String formatDisplayDate(DateTime date) {
    return DateFormat(displayDateFormat).format(date);
  }

  static String formatDateTime(DateTime date) {
    return DateFormat(dateTimeFormat).format(date);
  }

  static DateTime? parseDate(String dateString) {
    try {
      return DateFormat(dateFormat).parse(dateString);
    } catch (e) {
      return null;
    }
  }

  static int daysUntil(DateTime date) {
    final now = DateTime.now();
    final difference = date.difference(now);
    return difference.inDays;
  }

  static bool isExpired(DateTime date) {
    return date.isBefore(DateTime.now());
  }

  static bool isExpiringSoon(DateTime date, {int days = 30}) {
    final daysUntil = DateUtils.daysUntil(date);
    return daysUntil > 0 && daysUntil <= days;
  }

  static bool isCriticalExpiry(DateTime date, {int days = 7}) {
    final daysUntil = DateUtils.daysUntil(date);
    return daysUntil > 0 && daysUntil <= days;
  }

  static DateTime addYears(DateTime date, int years) {
    return DateTime(date.year + years, date.month, date.day);
  }

  static String getRelativeTime(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays == 0) {
      return 'Today';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else if (difference.inDays < 30) {
      return '${(difference.inDays / 7).floor()} weeks ago';
    } else if (difference.inDays < 365) {
      return '${(difference.inDays / 30).floor()} months ago';
    } else {
      return '${(difference.inDays / 365).floor()} years ago';
    }
  }
}