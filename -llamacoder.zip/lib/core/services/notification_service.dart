import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:warranty_tracker/core/constants/app_constants.dart';
import 'package:warranty_tracker/core/utils/logger.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _notifications = FlutterLocalNotificationsPlugin();
  bool _isInitialized = false;

  bool get isInitialized => _isInitialized;

  static Future<void> initialize() async {
    await _instance._initialize();
  }

  Future<void> _initialize() async {
    try {
      const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
      const iosSettings = DarwinInitializationSettings(
        requestAlertPermission: true,
        requestBadgePermission: true,
        requestSoundPermission: true,
      );

      const initSettings = InitializationSettings(
        android: androidSettings,
        iOS: iosSettings,
      );

      await _notifications.initialize(
        initSettings,
        onDidReceiveNotificationResponse: _onNotificationTapped,
      );

      _isInitialized = true;
      Logger.info('Notification service initialized');
    } catch (e) {
      Logger.error('Failed to initialize notification service', e);
    }
  }

  Future<void> requestPermissions() async {
    try {
      final android = _notifications.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      await android?.requestNotificationsPermission();

      final ios = _notifications.resolvePlatformSpecificImplementation<
          IOSFlutterLocalNotificationsPlugin>();
      await ios?.requestPermissions(
        alert: true,
        badge: true,
        sound: true,
      );

      Logger.info('Notification permissions requested');
    } catch (e) {
      Logger.error('Failed to request notification permissions', e);
    }
  }

  Future<void> showWarrantyExpiryNotification({
    required String warrantyId,
    required String productName,
    required DateTime expiryDate,
    required int daysUntil,
  }) async {
    try {
      final String title;
      final String body;

      if (daysUntil <= 0) {
        title = 'Warranty Expired';
        body = '$productName warranty has expired';
      } else if (daysUntil <= AppConstants.criticalExpiryDays) {
        title = 'Warranty Expiring Soon!';
        body = '$productName warranty expires in $daysUntil day${daysUntil == 1 ? '' : 's'}';
      } else {
        title = 'Warranty Reminder';
        body = '$productName warranty expires in $daysUntil days';
      }

      const notificationDetails = NotificationDetails(
        android: AndroidNotificationDetails(
          'warranty_expiry',
          'Warranty Expiry',
          channelDescription: 'Notifications for warranty expirations',
          importance: Importance.high,
          priority: Priority.high,
          color: Color(0xFF6366F1),
        ),
        iOS: DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      );

      await _notifications.show(
        warrantyId.hashCode,
        title,
        body,
        notificationDetails,
        payload: warrantyId,
      );

      Logger.info('Warranty expiry notification sent for $productName');
    } catch (e) {
      Logger.error('Failed to show warranty expiry notification', e);
    }
  }

  Future<void> scheduleWarrantyReminder({
    required String warrantyId,
    required String productName,
    required DateTime expiryDate,
    required int daysBefore,
  }) async {
    try {
      final scheduledDate = expiryDate.subtract(Duration(days: daysBefore));

      if (scheduledDate.isBefore(DateTime.now())) {
        return; // Don't schedule in the past
      }

      const notificationDetails = NotificationDetails(
        android: AndroidNotificationDetails(
          'warranty_reminders',
          'Warranty Reminders',
          channelDescription: 'Scheduled warranty reminders',
          importance: Importance.medium,
          priority: Priority.medium,
        ),
        iOS: DarwinNotificationDetails(),
      );

      await _notifications.zonedSchedule(
        '${warrantyId}_$daysBefore'.hashCode,
        'Warranty Reminder',
        '$productName warranty will expire in $daysBefore day${daysBefore == 1 ? '' : 's'}',
        tz.TZDateTime.from(scheduledDate, tz.local),
        notificationDetails,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
      );

      Logger.info('Scheduled warranty reminder for $productName');
    } catch (e) {
      Logger.error('Failed to schedule warranty reminder', e);
    }
  }

  Future<void> cancelNotification(String id) async {
    try {
      await _notifications.cancel(id.hashCode);
      Logger.info('Notification cancelled: $id');
    } catch (e) {
      Logger.error('Failed to cancel notification', e);
    }
  }

  Future<void> cancelAllNotifications() async {
    try {
      await _notifications.cancelAll();
      Logger.info('All notifications cancelled');
    } catch (e) {
      Logger.error('Failed to cancel all notifications', e);
    }
  }

  static void _onNotificationTapped(NotificationResponse response) {
    Logger.info('Notification tapped: ${response.payload}');
    // Handle navigation to warranty details
  }
}