import 'package:warranty_tracker/core/di/injection_container.dart';
import 'package:warranty_tracker/core/utils/logger.dart';
import 'package:warranty_tracker/premium/data/repositories/premium_repository_impl.dart';
import 'package:warranty_tracker/premium/domain/repositories/premium_repository.dart';

class PremiumService {
  static final PremiumService _instance = PremiumService._internal();
  factory PremiumService() => _instance;
  PremiumService._internal();

  final PremiumRepository _repository = sl<PremiumRepositoryImpl>();
  bool _isPremium = false;
  bool _isInitialized = false;

  bool get isPremium => _isPremium;
  bool get isInitialized => _isInitialized;

  Future<void> initialize() async {
    try {
      _isPremium = await _repository.isPremiumUser();
      _isInitialized = true;
      Logger.info('Premium service initialized. User is ${_isPremium ? 'premium' : 'free'}');
    } catch (e) {
      Logger.error('Failed to initialize premium service', e);
      _isPremium = false;
      _isInitialized = true;
    }
  }

  Future<bool> purchasePremium({
    required String platform,
    required String receipt,
    String? transactionId,
  }) async {
    try {
      final success = await _repository.purchasePremium(
        platform: platform,
        receipt: receipt,
        transactionId: transactionId,
      );

      if (success) {
        _isPremium = true;
        Logger.info('Premium purchase successful');
      }

      return success;
    } catch (e) {
      Logger.error('Premium purchase failed', e);
      return false;
    }
  }

  Future<bool> restorePurchases() async {
    try {
      final success = await _repository.restorePurchases();
      if (success) {
        _isPremium = await _repository.isPremiumUser();
        Logger.info('Purchases restored. User is ${_isPremium ? 'premium' : 'free'}');
      }
      return success;
    } catch (e) {
      Logger.error('Failed to restore purchases', e);
      return false;
    }
  }

  Future<void> refreshPremiumStatus() async {
    try {
      _isPremium = await _repository.isPremiumUser();
      Logger.info('Premium status refreshed. User is ${_isPremium ? 'premium' : 'free'}');
    } catch (e) {
      Logger.error('Failed to refresh premium status', e);
    }
  }

  void clearPremiumStatus() {
    _isPremium = false;
    Logger.info('Premium status cleared');
  }
}