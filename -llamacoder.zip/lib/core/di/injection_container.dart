import 'package:get_it/get_it.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

// Auth
import 'package:warranty_tracker/auth/data/repositories/auth_repository_impl.dart';
import 'package:warranty_tracker/auth/data/datasources/auth_remote_datasource.dart';
import 'package:warranty_tracker/auth/domain/repositories/auth_repository.dart';
import 'package:warranty_tracker/auth/domain/usecases/sign_in_usecase.dart';
import 'package:warranty_tracker/auth/domain/usecases/sign_up_usecase.dart';
import 'package:warranty_tracker/auth/domain/usecases/sign_out_usecase.dart';
import 'package:warranty_tracker/auth/domain/usecases/get_current_user_usecase.dart';
import 'package:warranty_tracker/auth/presentation/bloc/auth_bloc.dart';

// Warranty
import 'package:warranty_tracker/warranty/data/repositories/warranty_repository_impl.dart';
import 'package:warranty_tracker/warranty/data/datasources/warranty_remote_datasource.dart';
import 'package:warranty_tracker/warranty/data/datasources/warranty_local_datasource.dart';
import 'package:warranty_tracker/warranty/domain/repositories/warranty_repository.dart';
import 'package:warranty_tracker/warranty/domain/usecases/add_warranty_usecase.dart';
import 'package:warranty_tracker/warranty/domain/usecases/get_warranties_usecase.dart';
import 'package:warranty_tracker/warranty/domain/usecases/update_warranty_usecase.dart';
import 'package:warranty_tracker/warranty/domain/usecases/delete_warranty_usecase.dart';
import 'package:warranty_tracker/warranty/domain/usecases/process_ocr_usecase.dart';
import 'package:warranty_tracker/warranty/presentation/bloc/warranty_bloc.dart';

// Premium
import 'package:warranty_tracker/premium/data/repositories/premium_repository_impl.dart';
import 'package:warranty_tracker/premium/data/datasources/premium_remote_datasource.dart';
import 'package:warranty_tracker/premium/domain/repositories/premium_repository.dart';
import 'package:warranty_tracker/premium/domain/usecases/purchase_premium_usecase.dart';
import 'package:warranty_tracker/premium/domain/usecases/restore_purchases_usecase.dart';
import 'package:warranty_tracker/premium/domain/usecases/check_premium_status_usecase.dart';

// Notifications
import 'package:warranty_tracker/notifications/data/repositories/notification_repository_impl.dart';
import 'package:warranty_tracker/notifications/data/datasources/notification_local_datasource.dart';
import 'package:warranty_tracker/notifications/domain/repositories/notification_repository.dart';
import 'package:warranty_tracker/notifications/domain/usecases/get_notifications_usecase.dart';
import 'package:warranty_tracker/notifications/presentation/bloc/notification_bloc.dart';

final sl = GetIt.instance;

Future<void> init() async {
  // External dependencies
  sl.registerLazyInstance(() => FirebaseFirestore.instance);
  sl.registerLazyInstance(() => FirebaseAuth.instance);

  // Core services
  sl.registerLazySingleton(() => PremiumService());

  // Auth
  sl.registerLazySingleton<AuthRemoteDataSource>(
    () => AuthRemoteDataSourceImpl(firebaseAuth: sl()),
  );
  sl.registerLazySingleton<AuthRepository>(
    () => AuthRepositoryImpl(remoteDataSource: sl()),
  );
  sl.registerLazySingleton(() => SignInUseCase(sl()));
  sl.registerLazySingleton(() => SignUpUseCase(sl()));
  sl.registerLazySingleton(() => SignOutUseCase(sl()));
  sl.registerLazySingleton(() => GetCurrentUserUseCase(sl()));
  sl.registerFactory(() => AuthBloc(
        signInUseCase: sl(),
        signUpUseCase: sl(),
        signOutUseCase: sl(),
        getCurrentUserUseCase: sl(),
      ));

  // Warranty
  sl.registerLazySingleton<WarrantyRemoteDataSource>(
    () => WarrantyRemoteDataSourceImpl(firestore: sl()),
  );
  sl.registerLazySingleton<WarrantyLocalDataSource>(
    () => WarrantyLocalDataSourceImpl(),
  );
  sl.registerLazySingleton<WarrantyRepository>(
    () => WarrantyRepositoryImpl(
      remoteDataSource: sl(),
      localDataSource: sl(),
    ),
  );
  sl.registerLazySingleton(() => AddWarrantyUseCase(sl()));
  sl.registerLazySingleton(() => GetWarrantiesUseCase(sl()));
  sl.registerLazySingleton(() => UpdateWarrantyUseCase(sl()));
  sl.registerLazySingleton(() => DeleteWarrantyUseCase(sl()));
  sl.registerLazySingleton(() => ProcessOcrUseCase(sl()));
  sl.registerFactory(() => WarrantyBloc(
        addWarrantyUseCase: sl(),
        getWarrantiesUseCase: sl(),
        updateWarrantyUseCase: sl(),
        deleteWarrantyUseCase: sl(),
        processOcrUseCase: sl(),
      ));

  // Premium
  sl.registerLazySingleton<PremiumRemoteDataSource>(
    () => PremiumRemoteDataSourceImpl(firestore: sl()),
  );
  sl.registerLazySingleton<PremiumRepository>(
    () => PremiumRepositoryImpl(remoteDataSource: sl()),
  );
  sl.registerLazySingleton(() => PurchasePremiumUseCase(sl()));
  sl.registerLazySingleton(() => RestorePurchasesUseCase(sl()));
  sl.registerLazySingleton(() => CheckPremiumStatusUseCase(sl()));

  // Notifications
  sl.registerLazySingleton<NotificationLocalDataSource>(
    () => NotificationLocalDataSourceImpl(),
  );
  sl.registerLazySingleton<NotificationRepository>(
    () => NotificationRepositoryImpl(localDataSource: sl()),
  );
  sl.registerLazySingleton(() => GetNotificationsUseCase(sl()));
  sl.registerFactory(() => NotificationBloc(getNotificationsUseCase: sl()));
}