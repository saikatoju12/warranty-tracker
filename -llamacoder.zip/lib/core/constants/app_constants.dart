class AppConstants {
  // App info
  static const String appName = 'Warranty Tracker';
  static const String appVersion = '1.0.0';
  
  // Premium pricing
  static const double premiumPrice = 19.99;
  static const String premiumCurrency = 'USD';
  
  // Storage limits
  static const int freeWarrantyLimit = 10;
  static const int maxImageSizeBytes = 10 * 1024 * 1024; // 10MB
  static const int maxNotesLength = 1000;
  static const int maxProductNameLength = 200;
  
  // Warranty durations (in years)
  static const List<int> warrantyDurations = [1, 2, 3, 5, 10];
  
  // Expiry thresholds (in days)
  static const int criticalExpiryDays = 7;
  static const int warningExpiryDays = 30;
  
  // Notification settings
  static const List<int> reminderDays = [1, 3, 7, 14, 30];
  static const String defaultReminderTime = '09:00';
  
  // API endpoints
  static const String ocrEndpoint = 'https://api.openai.com/v1/chat/completions';
  static const String exportEndpoint = 'https://api.warrantytracker.com/export';
  
  // Local storage keys
  static const String isFirstLaunchKey = 'is_first_launch';
  static const String themeKey = 'theme_mode';
  static const String notificationsEnabledKey = 'notifications_enabled';
  
  // Error messages
  static const String genericErrorMessage = 'Something went wrong. Please try again.';
  static const String networkErrorMessage = 'Please check your internet connection.';
  static const String authErrorMessage = 'Authentication failed. Please try again.';
  
  // Success messages
  static const String warrantyAddedMessage = 'Warranty added successfully!';
  static const String warrantyUpdatedMessage = 'Warranty updated successfully!';
  static const String warrantyDeletedMessage = 'Warranty deleted successfully!';
  static const String purchaseSuccessMessage = 'Purchase successful! Enjoy premium features.';
}