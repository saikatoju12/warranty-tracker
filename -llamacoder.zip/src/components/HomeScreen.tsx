import React, { useState, useEffect } from "react";
import { Plus, Camera, Settings } from "lucide-react";
import { useAuth } from "../hooks/useAuth";
import { WarrantyForm } from "./WarrantyForm";
import { WarrantyList } from "./WarrantyList";
import { ExpiryBanner } from "./ExpiryBanner";
import { Toast } from "./Toast";
import { AccountSettings } from "./AccountSettings";
import { Warranty } from "../types/warranty";
import type { User as AuthUser } from "../hooks/useAuth";

interface HomeScreenProps {
  user: AuthUser;
}

export function HomeScreen({ user }: HomeScreenProps) {
  const { signOut } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" } | null>(null);
  const [warranties, setWarranties] = useState<Warranty[]>([]);

  // Load warranties from localStorage on mount
  useEffect(() => {
    const loadWarranties = () => {
      try {
        const stored = localStorage.getItem("warranties");
        if (stored) {
          const parsedWarranties = JSON.parse(stored);
          setWarranties(parsedWarranties);
        }
      } catch (error) {
        console.error("Error loading warranties:", error);
      }
    };

    loadWarranties();
  }, []);

  // Save warranties to localStorage whenever they change
  useEffect(() => {
    if (warranties.length > 0) {
      localStorage.setItem("warranties", JSON.stringify(warranties));
    }
  }, [warranties]);

  const handleAddWarranty = (warranty: Warranty) => {
    setWarranties(prev => [...prev, { ...warranty, id: Date.now().toString() }]);
    setShowForm(false);
    setToast({ message: "Warranty added successfully!", type: "success" });
  };

  const handleDeleteWarranty = (id: string) => {
    setWarranties(prev => prev.filter(w => w.id !== id));
    setToast({ message: "Warranty deleted", type: "success" });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">W</span>
              </div>
              <h1 className="text-xl font-semibold text-gray-900">Warranty Tracker</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowSettings(true)}
                className="flex items-center space-x-2 text-sm text-gray-600 hover:text-gray-900"
              >
                <Settings className="w-4 h-4" />
                <span>Settings</span>
              </button>
              <span className="text-sm text-gray-600">
                Welcome, {user.name}
              </span>
              <button
                onClick={signOut}
                className="text-sm text-gray-500 hover:text-gray-700"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Expiry Banner */}
      <ExpiryBanner warranties={warranties} />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Action Buttons */}
        <div className="mb-8 flex flex-col sm:flex-row gap-4">
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center justify-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
          >
            <Plus className="w-5 h-5 mr-2" />
            Add Warranty
          </button>
          <button
            className="flex items-center justify-center px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            disabled
          >
            <Camera className="w-5 h-5 mr-2" />
            Scan Receipt (Coming Soon)
          </button>
        </div>

        {/* Warranty List */}
        <WarrantyList
          warranties={warranties}
          onDelete={handleDeleteWarranty}
        />
      </main>

      {/* Modals */}
      {showForm && (
        <WarrantyForm
          onClose={() => setShowForm(false)}
          onSubmit={handleAddWarranty}
        />
      )}

      {showSettings && (
        <AccountSettings
          onClose={() => setShowSettings(false)}
        />
      )}

      {/* Toast */}
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}