import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, Calendar, Store, MoreVertical, ChevronRight } from "lucide-react";
import { Warranty } from "../types/warranty";
import { getWarrantyStatus } from "../utils/dateUtils";

interface WarrantyCardProps {
  warranty: Warranty;
  onDelete: (id: string) => void;
  compact?: boolean;
}

export function WarrantyCard({ warranty, onDelete, compact = false }: WarrantyCardProps) {
  const [showActions, setShowActions] = useState(false);
  const status = getWarrantyStatus(warranty.expirationDate);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric"
    });
  };

  const getStatusColor = () => {
    switch (status.status) {
      case "critical":
        return "bg-red-100 text-red-700";
      case "warning":
        return "bg-amber-100 text-amber-700";
      case "expired":
        return "bg-gray-100 text-gray-700";
      default:
        return "bg-green-100 text-green-700";
    }
  };

  if (compact) {
    return (
      <Card className="bg-white border border-gray-200 mb-3">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <h4 className="font-medium text-gray-900">{warranty.productName}</h4>
              <p className="text-sm text-gray-600">{warranty.retailer}</p>
              <div className="flex items-center mt-2 space-x-4">
                <span className="text-xs text-gray-500">
                  Expires: {formatDate(warranty.expirationDate)}
                </span>
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${getStatusColor()}`}>
                  {status.label}
                </span>
              </div>
            </div>
            <ChevronRight className="h-5 w-5 text-gray-400" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white border border-gray-200 mb-4 shadow-sm">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900">{warranty.productName}</h3>
            <p className="text-sm text-gray-600 mt-1">{warranty.retailer}</p>
          </div>
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowActions(!showActions)}
              className="text-gray-400 hover:text-gray-600 h-8 w-8 p-0"
            >
              <MoreVertical className="h-4 w-4" />
            </Button>
            
            {showActions && (
              <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg border border-gray-200 z-10">
                <div className="py-1">
                  <button 
                    onClick={() => {
                      onDelete(warranty.id);
                      setShowActions(false);
                    }}
                    className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Purchase Date</span>
            <span className="font-medium text-gray-900">{formatDate(warranty.purchaseDate)}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Expiration Date</span>
            <span className="font-medium text-gray-900">{formatDate(warranty.expirationDate)}</span>
          </div>
        </div>
        
        <div className="mt-3 pt-3 border-t border-gray-100">
          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor()}`}>
            {status.label}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}