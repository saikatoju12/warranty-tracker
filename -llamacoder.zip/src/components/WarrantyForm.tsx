import React, { useState, useEffect } from 'react';
import { X, Package, Calendar, Store, FileText, Camera } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { OCRCamera } from './OCRCamera';
import { Warranty } from '../types/warranty';

interface WarrantyFormProps {
  warranty?: Warranty;
  onClose: () => void;
  onSubmit: (warrantyData: Omit<Warranty, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => Promise<void>;
}

interface OCRData {
  purchaseDate?: string;
  storeName?: string;
  productKeywords?: string[];
  serialNumber?: string;
  productName?: string;
  confidence: number;
}

export const WarrantyForm: React.FC<WarrantyFormProps> = ({ warranty, onClose, onSubmit }) => {
  const [formData, setFormData] = useState({
    productName: '',
    purchaseDate: '',
    expirationDate: '',
    warrantyDuration: '1',
    retailer: '',
    notes: '',
    documents: [] as string[]
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showOCR, setShowOCR] = useState(false);

  useEffect(() => {
    if (warranty) {
      setFormData({
        productName: warranty.productName,
        purchaseDate: warranty.purchaseDate,
        expirationDate: warranty.expirationDate,
        warrantyDuration: warranty.warrantyDuration,
        retailer: warranty.retailer,
        notes: warranty.notes,
        documents: warranty.documents || []
      });
    }
  }, [warranty]);

  const handleOCRComplete = (ocrData: OCRData) => {
    // Auto-fill form with OCR data
    setFormData(prev => ({
      ...prev,
      productName: ocrData.productName || ocrData.productKeywords?.join(' ') || prev.productName,
      purchaseDate: ocrData.purchaseDate || prev.purchaseDate,
      retailer: ocrData.storeName || prev.retailer,
      notes: ocrData.serialNumber 
        ? `Serial Number: ${ocrData.serialNumber}\n${prev.notes}`
        : prev.notes
    }));
    
    // Auto-calculate expiration if we have purchase date
    if (ocrData.purchaseDate) {
      handleDurationChange(formData.warrantyDuration);
    }
    
    setShowOCR(false);
  };

  const handleDurationChange = (duration: string) => {
    setFormData(prev => ({ ...prev, warrantyDuration: duration }));
    
    // Auto-calculate expiration date
    if (formData.purchaseDate) {
      const purchaseDate = new Date(formData.purchaseDate);
      const expirationDate = new Date(purchaseDate);
      expirationDate.setFullYear(expirationDate.getFullYear() + parseInt(duration));
      
      setFormData(prev => ({
        ...prev,
        warrantyDuration: duration,
        expirationDate: expirationDate.toISOString().split('T')[0]
      }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.productName.trim()) {
      newErrors.productName = 'Product name is required';
    }

    if (!formData.purchaseDate) {
      newErrors.purchaseDate = 'Purchase date is required';
    }

    if (!formData.expirationDate) {
      newErrors.expirationDate = 'Expiration date is required';
    }

    if (!formData.retailer.trim()) {
      newErrors.retailer = 'Retailer is required';
    }

    if (formData.purchaseDate && formData.expirationDate) {
      const purchaseDate = new Date(formData.purchaseDate);
      const expirationDate = new Date(formData.expirationDate);
      
      if (expirationDate <= purchaseDate) {
        newErrors.expirationDate = 'Expiration date must be after purchase date';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit(formData);
      onClose();
    } catch (error) {
      console.error('Failed to save warranty:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* OCR Button */}
        <div className="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-indigo-900">Quick Add with OCR</h4>
              <p className="text-sm text-indigo-700">Scan a receipt to auto-fill warranty details</p>
            </div>
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowOCR(true)}
              className="bg-white hover:bg-gray-50"
            >
              <Camera className="w-4 h-4 mr-2" />
              Scan Receipt
            </Button>
          </div>
        </div>

        {/* Product Name */}
        <div>
          <Label htmlFor="productName" className="flex items-center space-x-2">
            <Package className="w-4 h-4" />
            <span>Product Name *</span>
          </Label>
          <Input
            id="productName"
            value={formData.productName}
            onChange={(e) => {
              setFormData(prev => ({ ...prev, productName: e.target.value }));
              if (errors.productName) {
                setErrors(prev => ({ ...prev, productName: '' }));
              }
            }}
            placeholder="Enter product name"
            className={errors.productName ? 'border-red-500' : ''}
          />
          {errors.productName && (
            <p className="text-sm text-red-500 mt-1">{errors.productName}</p>
          )}
        </div>

        {/* Purchase Date */}
        <div>
          <Label htmlFor="purchaseDate" className="flex items-center space-x-2">
            <Calendar className="w-4 h-4" />
            <span>Purchase Date *</span>
          </Label>
          <Input
            id="purchaseDate"
            type="date"
            value={formData.purchaseDate}
            onChange={(e) => {
              setFormData(prev => ({ ...prev, purchaseDate: e.target.value }));
              if (errors.purchaseDate) {
                setErrors(prev => ({ ...prev, purchaseDate: '' }));
              }
              // Recalculate expiration date when purchase date changes
              handleDurationChange(formData.warrantyDuration);
            }}
            className={errors.purchaseDate ? 'border-red-500' : ''}
          />
          {errors.purchaseDate && (
            <p className="text-sm text-red-500 mt-1">{errors.purchaseDate}</p>
          )}
        </div>

        {/* Warranty Duration */}
        <div>
          <Label htmlFor="warrantyDuration">Warranty Duration</Label>
          <Select value={formData.warrantyDuration} onValueChange={handleDurationChange}>
            <SelectTrigger>
              <SelectValue placeholder="Select warranty duration" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1 Year</SelectItem>
              <SelectItem value="2">2 Years</SelectItem>
              <SelectItem value="3">3 Years</SelectItem>
              <SelectItem value="5">5 Years</SelectItem>
              <SelectItem value="10">10 Years</SelectItem>
              <SelectItem value="lifetime">Lifetime</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Expiration Date */}
        <div>
          <Label htmlFor="expirationDate" className="flex items-center space-x-2">
            <Calendar className="w-4 h-4" />
            <span>Expiration Date *</span>
          </Label>
          <Input
            id="expirationDate"
            type="date"
            value={formData.expirationDate}
            onChange={(e) => {
              setFormData(prev => ({ ...prev, expirationDate: e.target.value }));
              if (errors.expirationDate) {
                setErrors(prev => ({ ...prev, expirationDate: '' }));
              }
            }}
            className={errors.expirationDate ? 'border-red-500' : ''}
          />
          {errors.expirationDate && (
            <p className="text-sm text-red-500 mt-1">{errors.expirationDate}</p>
          )}
        </div>

        {/* Retailer */}
        <div>
          <Label htmlFor="retailer" className="flex items-center space-x-2">
            <Store className="w-4 h-4" />
            <span>Retailer *</span>
          </Label>
          <Input
            id="retailer"
            value={formData.retailer}
            onChange={(e) => {
              setFormData(prev => ({ ...prev, retailer: e.target.value }));
              if (errors.retailer) {
                setErrors(prev => ({ ...prev, retailer: '' }));
              }
            }}
            placeholder="Enter retailer name"
            className={errors.retailer ? 'border-red-500' : ''}
          />
          {errors.retailer && (
            <p className="text-sm text-red-500 mt-1">{errors.retailer}</p>
          )}
        </div>

        {/* Notes */}
        <div>
          <Label htmlFor="notes" className="flex items-center space-x-2">
            <FileText className="w-4 h-4" />
            <span>Notes</span>
          </Label>
          <Textarea
            id="notes"
            value={formData.notes}
            onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
            placeholder="Add any additional notes about this warranty..."
            rows={4}
          />
        </div>

        {/* Submit Button */}
        <div className="flex items-center justify-end space-x-4 pt-4 border-t">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            className="bg-indigo-600 hover:bg-indigo-700"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Saving...' : warranty ? 'Update Warranty' : 'Submit Warranty'}
          </Button>
        </div>
      </form>

      {/* OCR Camera Modal */}
      {showOCR && (
        <OCRCamera
          onOCRComplete={handleOCRComplete}
          onClose={() => setShowOCR(false)}
        />
      )}
    </>
  );
};