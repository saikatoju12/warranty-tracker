import React, { useState, useEffect } from 'react';
import { Bell, X, AlertTriangle, Clock, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useAuth } from '../contexts/AuthContext';
import { useNotifications } from '../hooks/useNotifications';
import { Warranty } from '../types/warranty';

interface ExpiringWarranty {
  warranty: Warranty;
  daysUntilExpiration: number;
}

export const NotificationBanner: React.FC = () => {
  const { user } = useAuth();
  const { testNotification } = useNotifications();
  const [expiringWarranties, setExpiringWarranties] = useState<ExpiringWarranty[]>([]);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    if (user) {
      checkExpiringWarranties();
    }
  }, [user]);

  const checkExpiringWarranties = () => {
    try {
      const stored = localStorage.getItem('warranties');
      if (!stored) return;

      const allWarranties: Warranty[] = JSON.parse(stored);
      const userWarranties = allWarranties.filter(w => w.userId === user?.id);
      
      const now = new Date();
      const expiring = userWarranties
        .map(warranty => ({
          warranty,
          daysUntilExpiration: Math.ceil((new Date(warranty.expirationDate).getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
        }))
        .filter(item => item.daysUntilExpiration <= 30 && item.daysUntilExpiration >= -7)
        .sort((a, b) => a.daysUntilExpiration - b.daysUntilExpiration);

      setExpiringWarranties(expiring);
    } catch (error) {
      console.error('Error checking expiring warranties:', error);
    }
  };

  const getStatusIcon = (days: number) => {
    if (days <= 0) return <AlertTriangle className="w-4 h-4 text-red-500" />;
    if (days <= 7) return <Clock className="w-4 h-4 text-yellow-500" />;
    return <CheckCircle className="w-4 h-4 text-green-500" />;
  };

  const getStatusColor = (days: number) => {
    if (days <= 0) return 'bg-red-50 border-red-200 text-red-800';
    if (days <= 7) return 'bg-yellow-50 border-yellow-200 text-yellow-800';
    return 'bg-green-50 border-green-200 text-green-800';
  };

  const getStatusText = (days: number) => {
    if (days === 0) return 'Expires today';
    if (days < 0) return `Expired ${Math.abs(days)} days ago`;
    if (days === 1) return 'Expires tomorrow';
    return `Expires in ${days} days`;
  };

  if (expiringWarranties.length === 0 || !isVisible) {
    return null;
  }

  return (
    <div className="bg-gradient-to-r from-indigo-50 to-purple-50 border-b border-indigo-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Bell className="w-5 h-5 text-indigo-600 animate-pulse" />
            <div>
              <p className="text-sm font-medium text-indigo-900">
                {expiringWarranties.length} warrant{expiringWarranties.length === 1 ? 'y' : 'ies'} need attention
              </p>
              <div className="flex flex-wrap gap-2 mt-1">
                {expiringWarranties.slice(0, 3).map((item, index) => (
                  <Badge
                    key={index}
                    variant="outline"
                    className={`text-xs ${getStatusColor(item.daysUntilExpiration)}`}
                  >
                    {getStatusIcon(item.daysUntilExpiration)}
                    <span className="ml-1">
                      {item.warranty.productName}: {getStatusText(item.daysUntilExpiration)}
                    </span>
                  </Badge>
                ))}
                {expiringWarranties.length > 3 && (
                  <Badge variant="outline" className="text-xs bg-gray-50 border-gray-200 text-gray-800">
                    +{expiringWarranties.length - 3} more
                  </Badge>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              size="sm"
              variant="outline"
              onClick={testNotification}
              className="text-xs"
            >
              Test Notifications
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setIsVisible(false)}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};