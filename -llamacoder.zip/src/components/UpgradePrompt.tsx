import React, { useState } from 'react';
import { Crown, X, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { usePremium } from '../hooks/usePremium';
import { useAuth } from '../contexts/AuthContext';

interface UpgradePromptProps {
  feature: string;
  onUpgrade?: () => void;
  onDismiss?: () => void;
}

export const UpgradePrompt: React.FC<UpgradePromptProps> = ({ 
  feature, 
  onUpgrade, 
  onDismiss 
}) => {
  const { user } = useAuth();
  const { purchasePremium, isProcessing } = usePremium();
  const [isDismissed, setIsDismissed] = useState(false);

  if (user?.isPremium || isDismissed) {
    return null;
  }

  const handleUpgrade = async () => {
    try {
      await purchasePremium('premium');
      onUpgrade?.();
    } catch (error) {
      console.error('Upgrade failed:', error);
    }
  };

  const handleDismiss = () => {
    setIsDismissed(true);
    onDismiss?.();
  };

  return (
    <div className="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 rounded-lg p-4 mb-4">
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3">
          <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0">
            <Crown className="w-4 h-4 text-indigo-600" />
          </div>
          <div>
            <div className="flex items-center space-x-2 mb-1">
              <h4 className="font-medium text-indigo-900">Unlock Premium Features</h4>
              <Badge className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white text-xs">
                Limited Time
              </Badge>
            </div>
            <p className="text-sm text-indigo-700 mb-3">
              Get advanced OCR, unlimited storage, and more with a one-time purchase.
            </p>
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                onClick={handleUpgrade}
                disabled={isProcessing}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
              >
                {isProcessing ? (
                  <div className="flex items-center space-x-2">
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                    <span>Processing...</span>
                  </div>
                ) : (
                  <>
                    <Sparkles className="w-3 h-3 mr-1" />
                    Upgrade Now
                  </>
                )}
              </Button>
              <Button size="sm" variant="ghost" onClick={handleDismiss}>
                Maybe Later
              </Button>
            </div>
          </div>
        </div>
        <Button variant="ghost" size="sm" onClick={handleDismiss}>
          <X className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
};