import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Mail, Lock, Eye, EyeOff, Chrome, Apple, User } from "lucide-react";
import { useAuth } from "../../hooks/useAuth";
import { Toast } from "../Toast";

export function LoginScreen() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" } | null>(null);
  
  const { signInWithEmail, signInWithGoogle, signInWithApple, signInAsGuest } = useAuth();

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      setToast({ message: "Please fill in all fields", type: "error" });
      return;
    }

    setIsLoading(true);
    try {
      await signInWithEmail(email, password);
    } catch (error) {
      setToast({ message: "Invalid email or password", type: "error" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    try {
      await signInWithGoogle();
    } catch (error) {
      setToast({ message: "Google sign-in failed", type: "error" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    setIsLoading(true);
    try {
      await signInWithApple();
    } catch (error) {
      setToast({ message: "Apple sign-in failed", type: "error" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleGuestLogin = async () => {
    setIsLoading(true);
    try {
      await signInAsGuest();
    } catch (error) {
      setToast({ message: "Guest login failed", type: "error" });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white flex flex-col justify-center px-4">
      <div className="max-w-md w-full mx-auto">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Mail className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Welcome Back</h1>
          <p className="text-gray-600">Sign in to access your warranties</p>
        </div>

        {/* Email/Password Form */}
        <form onSubmit={handleEmailLogin} className="space-y-4 mb-6">
          <div>
            <Label htmlFor="email" className="text-sm font-medium text-gray-700">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              className="mt-1"
              disabled={isLoading}
            />
          </div>
          
          <div>
            <Label htmlFor="password" className="text-sm font-medium text-gray-700">Password</Label>
            <div className="relative mt-1">
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                disabled={isLoading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <Button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700"
            disabled={isLoading}
          >
            {isLoading ? "Signing in..." : "Sign In"}
          </Button>
        </form>

        <div className="relative mb-6">
          <Separator />
          <span className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white px-2 text-xs text-gray-500">
            OR
          </span>
        </div>

        {/* Social Login */}
        <div className="space-y-3 mb-6">
          <Button
            onClick={handleGoogleLogin}
            variant="outline"
            className="w-full border-gray-300 hover:bg-gray-50"
            disabled={isLoading}
          >
            <Chrome className="h-4 w-4 mr-2" />
            Continue with Google
          </Button>
          
          <Button
            onClick={handleAppleLogin}
            variant="outline"
            className="w-full border-gray-300 hover:bg-gray-50"
            disabled={isLoading}
          >
            <Apple className="h-4 w-4 mr-2" />
            Continue with Apple
          </Button>
        </div>

        {/* Guest Mode */}
        <div className="text-center">
          <Button
            onClick={handleGuestLogin}
            variant="ghost"
            className="text-gray-600 hover:text-gray-900"
            disabled={isLoading}
          >
            <User className="h-4 w-4 mr-2" />
            Continue as Guest
          </Button>
          <p className="text-xs text-gray-500 mt-2">
            Limited features • Upgrade anytime
          </p>
        </div>

        {/* Sign Up Link */}
        <div className="text-center mt-6">
          <p className="text-sm text-gray-600">
            Don't have an account?{" "}
            <button className="text-blue-600 hover:text-blue-700 font-medium">
              Sign up
            </button>
          </p>
        </div>
      </div>

      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}