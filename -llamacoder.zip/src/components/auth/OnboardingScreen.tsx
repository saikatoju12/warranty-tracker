import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronRight, ChevronLeft, Shield, Bell, BarChart3, Globe } from "lucide-react";

interface OnboardingScreenProps {
  onComplete: () => void;
}

export function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      icon: Shield,
      title: "Track All Your Warranties",
      description: "Never lose track of product warranties again. Store everything in one secure place.",
      color: "bg-blue-600"
    },
    {
      icon: Bell,
      title: "Smart Expiration Alerts",
      description: "Get notified before your warranties expire. Never miss claiming a warranty again.",
      color: "bg-amber-600"
    },
    {
      icon: BarChart3,
      title: "AI-Powered Insights",
      description: "Our AI automatically extracts warranty details from your receipts and documents.",
      color: "bg-purple-600"
    },
    {
      icon: Globe,
      title: "Global Coverage",
      description: "Works with retailers worldwide. Your warranties, wherever you shop.",
      color: "bg-green-600"
    }
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      localStorage.setItem("hasSeenOnboarding", "true");
      onComplete();
    }
  };

  const handlePrevious = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const currentSlideData = slides[currentSlide];
  const Icon = currentSlideData.icon;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white flex flex-col">
      {/* Progress Indicator */}
      <div className="flex justify-center pt-8 pb-4">
        <div className="flex space-x-2">
          {slides.map((_, index) => (
            <div
              key={index}
              className={`h-2 rounded-full transition-all duration-300 ${
                index === currentSlide ? "w-8 bg-blue-600" : "w-2 bg-gray-300"
              }`}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-8">
        <div className={`w-20 h-20 ${currentSlideData.color} rounded-2xl flex items-center justify-center mb-8 shadow-lg`}>
          <Icon className="h-10 w-10 text-white" />
        </div>
        
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-4">
          {currentSlideData.title}
        </h2>
        
        <p className="text-gray-600 text-center text-lg leading-relaxed max-w-sm">
          {currentSlideData.description}
        </p>
      </div>

      {/* Navigation */}
      <div className="p-8">
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={handlePrevious}
            disabled={currentSlide === 0}
            className="text-gray-600 hover:text-gray-900"
          >
            <ChevronLeft className="h-4 w-4 mr-2" />
            Previous
          </Button>
          
          <span className="text-sm text-gray-500">
            {currentSlide + 1} of {slides.length}
          </span>
          
          <Button
            onClick={handleNext}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            {currentSlide === slides.length - 1 ? "Get Started" : "Next"}
            <ChevronRight className="h-4 w-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}