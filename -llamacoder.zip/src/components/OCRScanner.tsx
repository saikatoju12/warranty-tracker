import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Camera, Upload, X, Loader2, CheckCircle } from "lucide-react";

interface OCRScannerProps {
  onScan: (data: any) => void;
  onCancel: () => void;
}

export function OCRScanner({ onScan, onCancel }: OCRScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(false);

  const handleCameraScan = () => {
    setIsScanning(true);
    
    setTimeout(() => {
      setIsScanning(false);
      setScanComplete(true);
      
      setTimeout(() => {
        onScan({});
      }, 1500);
    }, 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setIsScanning(true);
      
      setTimeout(() => {
        setIsScanning(false);
        setScanComplete(true);
        
        setTimeout(() => {
          onScan({});
        }, 1500);
      }, 2000);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
      <div className="bg-white rounded-t-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-900">Scan Document</h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={onCancel}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        <div className="p-6">
          {!isScanning && !scanComplete ? (
            <div className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                <p className="text-sm text-blue-800">
                  AI will automatically extract warranty details from your document
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <Button
                  onClick={handleCameraScan}
                  className="h-24 flex flex-col items-center justify-center space-y-2 bg-blue-600 hover:bg-blue-700"
                >
                  <Camera className="h-8 w-8" />
                  <span className="text-sm">Take Photo</span>
                </Button>
                
                <div className="relative">
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="file-upload"
                  />
                  <label htmlFor="file-upload">
                    <Button
                      type="button"
                      className="h-24 w-full flex flex-col items-center justify-center space-y-2"
                      variant="outline"
                    >
                      <Upload className="h-8 w-8" />
                      <span className="text-sm">Upload File</span>
                    </Button>
                  </label>
                </div>
              </div>
            </div>
          ) : isScanning ? (
            <div className="text-center py-12">
              <Loader2 className="h-12 w-12 text-blue-600 animate-spin mx-auto mb-4" />
              <p className="text-gray-900 font-medium mb-2">Processing document...</p>
              <p className="text-sm text-gray-600">Extracting warranty information</p>
            </div>
          ) : (
            <div className="text-center py-12">
              <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <p className="text-gray-900 font-medium mb-2">Scan complete!</p>
              <p className="text-sm text-gray-600">Document processed successfully</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}