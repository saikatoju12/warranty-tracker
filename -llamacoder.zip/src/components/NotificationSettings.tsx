import React, { useState, useEffect } from 'react';
import { Bell, Clock, Smartphone, Mail, Check, X } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../hooks/useToast';

interface NotificationPreferences {
  pushEnabled: boolean;
  emailEnabled: boolean;
  reminderDays: number[];
  reminderTime: string;
  expiredReminderEnabled: boolean;
}

export const NotificationSettings: React.FC = () => {
  const { user } = useAuth();
  const { addToast } = useToast();
  const [preferences, setPreferences] = useState<NotificationPreferences>({
    pushEnabled: true,
    emailEnabled: false,
    reminderDays: [7, 30],
    reminderTime: '09:00',
    expiredReminderEnabled: true
  });
  const [isSaving, setIsSaving] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermission>('default');

  useEffect(() => {
    loadPreferences();
    checkNotificationPermission();
  }, []);

  const loadPreferences = () => {
    if (user) {
      const stored = localStorage.getItem(`notificationPrefs_${user.id}`);
      if (stored) {
        setPreferences(JSON.parse(stored));
      }
    }
  };

  const checkNotificationPermission = async () => {
    if ('Notification' in window) {
      setPermissionStatus(Notification.permission);
    }
  };

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      setPermissionStatus(permission);
      
      if (permission === 'granted') {
        addToast({
          title: 'Notifications Enabled',
          description: 'You will receive warranty reminders',
          type: 'success'
        });
      } else {
        addToast({
          title: 'Notifications Blocked',
          description: 'Enable notifications in your browser settings',
          type: 'error'
        });
      }
    }
  };

  const savePreferences = async () => {
    if (!user) return;
    
    setIsSaving(true);
    try {
      localStorage.setItem(`notificationPrefs_${user.id}`, JSON.stringify(preferences));
      
      // Update Firebase subscription
      if (preferences.pushEnabled && permissionStatus === 'granted') {
        await subscribeToPushNotifications();
      } else {
        await unsubscribeFromPushNotifications();
      }
      
      addToast({
        title: 'Settings Saved',
        description: 'Your notification preferences have been updated',
        type: 'success'
      });
    } catch (error) {
      addToast({
        title: 'Error',
        description: 'Failed to save notification settings',
        type: 'error'
      });
    } finally {
      setIsSaving(false);
    }
  };

  const subscribeToPushNotifications = async () => {
    // Register service worker for push notifications
    if ('serviceWorker' in navigator && 'PushManager' in window) {
      try {
        const registration = await navigator.serviceWorker.register('/sw.js');
        const subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: 'YOUR_VAPID_PUBLIC_KEY'
        });
        
        // Send subscription to Firebase
        await fetch('/api/notifications/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ subscription, userId: user?.id })
        });
      } catch (error) {
        console.error('Failed to subscribe to push notifications:', error);
      }
    }
  };

  const unsubscribeFromPushNotifications = async () => {
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.ready;
        const subscription = await registration.pushManager.getSubscription();
        if (subscription) {
          await subscription.unsubscribe();
          await fetch('/api/notifications/unsubscribe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId: user?.id })
          });
        }
      } catch (error) {
        console.error('Failed to unsubscribe from push notifications:', error);
      }
    }
  };

  const toggleReminderDay = (day: number) => {
    setPreferences(prev => ({
      ...prev,
      reminderDays: prev.reminderDays.includes(day)
        ? prev.reminderDays.filter(d => d !== day)
        : [...prev.reminderDays, day]
    }));
  };

  return (
    <div className="space-y-6">
      {/* Push Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Smartphone className="w-5 h-5" />
            <span>Push Notifications</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Enable Push Notifications</Label>
              <p className="text-sm text-gray-600">Receive browser notifications for warranty reminders</p>
            </div>
            <Switch
              checked={preferences.pushEnabled}
              onCheckedChange={(checked) => setPreferences(prev => ({ ...prev, pushEnabled: checked }))}
            />
          </div>
          
          {preferences.pushEnabled && permissionStatus !== 'granted' && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <div className="flex items-center space-x-2">
                <Bell className="w-4 h-4 text-yellow-600" />
                <p className="text-sm text-yellow-800">Browser permission required</p>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={requestNotificationPermission}
                className="mt-2"
              >
                Enable Browser Notifications
              </Button>
            </div>
          )}
          
          {permissionStatus === 'granted' && (
            <div className="flex items-center space-x-2 text-green-600">
              <Check className="w-4 h-4" />
              <span className="text-sm">Browser notifications enabled</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Email Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Mail className="w-5 h-5" />
            <span>Email Notifications</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Enable Email Reminders</Label>
              <p className="text-sm text-gray-600">Receive email notifications for warranty updates</p>
            </div>
            <Switch
              checked={preferences.emailEnabled}
              onCheckedChange={(checked) => setPreferences(prev => ({ ...prev, emailEnabled: checked }))}
            />
          </div>
          
          {preferences.emailEnabled && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm text-blue-800">
                Emails will be sent to: {user?.email}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Reminder Schedule */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Clock className="w-5 h-5" />
            <span>Reminder Schedule</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Reminder Days Before Expiration</Label>
            <p className="text-sm text-gray-600 mb-3">Select when you want to be reminded</p>
            <div className="flex flex-wrap gap-2">
              {[1, 3, 7, 14, 30, 60].map(day => (
                <Button
                  key={day}
                  variant={preferences.reminderDays.includes(day) ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => toggleReminderDay(day)}
                >
                  {day} {day === 1 ? 'day' : 'days'}
                </Button>
              ))}
            </div>
          </div>

          <div>
            <Label>Reminder Time</Label>
            <Select value={preferences.reminderTime} onValueChange={(value) => setPreferences(prev => ({ ...prev, reminderTime: value }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="08:00">8:00 AM</SelectItem>
                <SelectItem value="09:00">9:00 AM</SelectItem>
                <SelectItem value="10:00">10:00 AM</SelectItem>
                <SelectItem value="12:00">12:00 PM</SelectItem>
                <SelectItem value="18:00">6:00 PM</SelectItem>
                <SelectItem value="20:00">8:00 PM</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Expired Warranty Reminders</Label>
              <p className="text-sm text-gray-600">Continue reminders after warranty expires</p>
            </div>
            <Switch
              checked={preferences.expiredReminderEnabled}
              onCheckedChange={(checked) => setPreferences(prev => ({ ...prev, expiredReminderEnabled: checked }))}
            />
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={savePreferences} disabled={isSaving} className="bg-indigo-600 hover:bg-indigo-700">
          {isSaving ? 'Saving...' : 'Save Settings'}
        </Button>
      </div>
    </div>
  );
};