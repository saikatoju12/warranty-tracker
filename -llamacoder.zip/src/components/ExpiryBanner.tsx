import React, { useState, useEffect, useRef } from "react";
import { AlertTriangle, X } from "lucide-react";
import { Warranty } from "../types/warranty";

interface ExpiryBannerProps {
  warranties: Warranty[];
}

export function ExpiryBanner({ warranties }: ExpiryBannerProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [hasPlayedSound, setHasPlayedSound] = useState(false);

  // Calculate expiring warranties
  const expiringWarranties = warranties.filter(warranty => {
    const today = new Date();
    const expiration = new Date(warranty.expirationDate);
    const daysUntilExpiration = Math.ceil((expiration.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiration >= 0 && daysUntilExpiration <= 30;
  });

  const criticalWarranties = warranties.filter(warranty => {
    const today = new Date();
    const expiration = new Date(warranty.expirationDate);
    const daysUntilExpiration = Math.ceil((expiration.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiration >= 0 && daysUntilExpiration <= 7;
  });

  // Play sound for critical warranties
  useEffect(() => {
    if (criticalWarranties.length > 0 && !hasPlayedSound && isVisible) {
      // Create a simple beep sound using Web Audio API
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = 800;
      oscillator.type = "sine";
      
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
      
      setHasPlayedSound(true);
    }
  }, [criticalWarranties.length, hasPlayedSound, isVisible]);

  if (expiringWarranties.length === 0 || !isVisible) {
    return null;
  }

  return (
    <div className="bg-yellow-50 border-b border-yellow-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <AlertTriangle className="w-5 h-5 text-yellow-600 mr-2" />
            <span className="text-sm font-medium text-yellow-800">
              {expiringWarranties.length} warrant{expiringWarranties.length === 1 ? 'y' : 'ies'} expiring soon
              {criticalWarranties.length > 0 && (
                <span className="ml-2 text-red-600 font-semibold">
                  ({criticalWarranties.length} critical)
                </span>
              )}
            </span>
          </div>
          <button
            onClick={() => setIsVisible(false)}
            className="text-yellow-600 hover:text-yellow-700"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}