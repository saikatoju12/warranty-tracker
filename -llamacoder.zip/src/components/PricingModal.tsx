import React, { useState } from 'react';
import { Check, X, Crown, Star, Zap, Shield, Download, Mail, Users, FileText } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { useAuth } from '../contexts/AuthContext';
import { usePremium } from '../hooks/usePremium';

interface PricingModalProps {
  onClose: () => void;
}

export const PricingModal: React.FC<PricingModalProps> = ({ onClose }) => {
  const { user } = useAuth();
  const { purchasePremium, restorePurchase, isProcessing } = usePremium();
  const [selectedPlan, setSelectedPlan] = useState<'premium' | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);

  const handlePurchase = async (plan: 'premium') => {
    setSelectedPlan(plan);
    try {
      await purchasePremium(plan);
      setShowSuccess(true);
      setTimeout(() => {
        setShowSuccess(false);
        onClose();
      }, 3000);
    } catch (error) {
      console.error('Purchase failed:', error);
    } finally {
      setSelectedPlan(null);
    }
  };

  const handleRestore = async () => {
    try {
      await restorePurchase();
    } catch (error) {
      console.error('Restore failed:', error);
    }
  };

  const freeFeatures = [
    { icon: FileText, text: 'Manual warranty entry', included: true },
    { icon: Zap, text: 'Basic OCR (Google ML Kit)', included: true },
    { icon: Shield, text: 'Local storage only', included: true },
    { icon: Users, text: 'Single user profile', included: true },
    { icon: Mail, text: 'Email receipt scanning', included: false },
    { icon: Star, text: 'Advanced OCR (OpenAI Vision)', included: false },
    { icon: Shield, text: 'Unlimited cloud storage', included: false },
    { icon: Users, text: 'Multiple profiles', included: false },
    { icon: Download, text: 'Export to PDF', included: false },
    { icon: X, text: 'No ads', included: false }
  ];

  const premiumFeatures = [
    { icon: FileText, text: 'Manual warranty entry', included: true },
    { icon: Zap, text: 'Basic OCR (Google ML Kit)', included: true },
    { icon: Shield, text: 'Local storage only', included: true },
    { icon: Users, text: 'Single user profile', included: true },
    { icon: Mail, text: 'Email receipt scanning', included: true },
    { icon: Star, text: 'Advanced OCR (OpenAI Vision)', included: true },
    { icon: Shield, text: 'Unlimited cloud storage', included: true },
    { icon: Users, text: 'Multiple profiles (family sharing)', included: true },
    { icon: Download, text: 'Export to PDF & CSV', included: true },
    { icon: X, text: 'No ads forever', included: true }
  ];

  if (showSuccess) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Welcome to Premium!</h3>
            <p className="text-gray-600 mb-4">
              Your premium features are now active. Enjoy unlimited storage and advanced OCR!
            </p>
            <Button onClick={onClose} className="bg-green-600 hover:bg-green-700">
              Get Started
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Upgrade to Premium</h2>
              <p className="text-gray-600 mt-1">Unlock advanced features and unlimited storage</p>
            </div>
            <Button variant="ghost" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="p-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Free Plan */}
            <Card className="relative">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Free</span>
                  <Badge variant="outline">Current Plan</Badge>
                </CardTitle>
                <div className="mt-2">
                  <span className="text-3xl font-bold">$0</span>
                  <span className="text-gray-600">/forever</span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {freeFeatures.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      {feature.included ? (
                        <Check className="w-4 h-4 text-green-600 flex-shrink-0" />
                      ) : (
                        <X className="w-4 h-4 text-gray-400 flex-shrink-0" />
                      )}
                      <span className={`text-sm ${feature.included ? 'text-gray-900' : 'text-gray-500'}`}>
                        {feature.text}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Premium Plan */}
            <Card className="relative border-2 border-indigo-500 shadow-lg">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
                  <Crown className="w-3 h-3 mr-1" />
                  Most Popular
                </Badge>
              </div>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Premium</span>
                  <Badge className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
                    Lifetime
                  </Badge>
                </CardTitle>
                <div className="mt-2">
                  <span className="text-3xl font-bold">$19.99</span>
                  <span className="text-gray-600">/one-time</span>
                </div>
                <p className="text-sm text-indigo-600 mt-2">
                  One-time purchase, lifetime access
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {premiumFeatures.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      {feature.included ? (
                        <Check className="w-4 h-4 text-green-600 flex-shrink-0" />
                      ) : (
                        <X className="w-4 h-4 text-gray-400 flex-shrink-0" />
                      )}
                      <span className={`text-sm ${feature.included ? 'text-gray-900' : 'text-gray-500'}`}>
                        {feature.text}
                      </span>
                    </div>
                  ))}
                </div>
                <Button
                  onClick={() => handlePurchase('premium')}
                  disabled={isProcessing || selectedPlan === 'premium'}
                  className="w-full mt-6 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                >
                  {isProcessing && selectedPlan === 'premium' ? (
                    <div className="flex items-center space-x-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      <span>Processing...</span>
                    </div>
                  ) : (
                    <>
                      <Crown className="w-4 h-4 mr-2" />
                      Upgrade to Premium
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Restore Purchase */}
          <div className="mt-6 text-center">
            <Button
              variant="outline"
              onClick={handleRestore}
              disabled={isProcessing}
              className="text-sm"
            >
              Restore Purchase
            </Button>
          </div>

          {/* Trust Badges */}
          <div className="mt-8 pt-6 border-t">
            <div className="flex flex-wrap justify-center items-center gap-6 text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4" />
                <span>Secure Payment</span>
              </div>
              <div className="flex items-center space-x-2">
                <Check className="w-4 h-4" />
                <span>30-Day Money Back</span>
              </div>
              <div className="flex items-center space-x-2">
                <Users className="w-4 h-4" />
                <span>Family Sharing</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};