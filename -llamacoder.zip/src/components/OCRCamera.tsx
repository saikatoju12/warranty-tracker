import React, { useState, useRef, useCallback } from 'react';
import { Camera, X, RotateCw, Check, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { useAuth } from '../contexts/AuthContext';

interface OCRData {
  purchaseDate?: string;
  storeName?: string;
  productKeywords?: string[];
  serialNumber?: string;
  productName?: string;
  confidence: number;
}

interface OCRCameraProps {
  onOCRComplete: (data: OCRData) => void;
  onClose: () => void;
}

export const OCRCamera: React.FC<OCRCameraProps> = ({ onOCRComplete, onClose }) => {
  const { user } = useAuth();
  const [isCapturing, setIsCapturing] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [ocrData, setOCRData] = useState<OCRData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCapturing(true);
      }
    } catch (err) {
      setError('Camera access denied. Please use file upload instead.');
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCapturing(false);
  };

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        const imageData = canvas.toDataURL('image/jpeg');
        setCapturedImage(imageData);
        stopCamera();
        processImage(imageData);
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const imageData = event.target?.result as string;
        setCapturedImage(imageData);
        processImage(imageData);
      };
      reader.readAsDataURL(file);
    }
  };

  const preprocessImage = (imageData: string): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (ctx) {
          // Enhance contrast and brightness for better OCR
          canvas.width = img.width;
          canvas.height = img.height;
          ctx.filter = 'contrast(1.5) brightness(1.2)';
          ctx.drawImage(img, 0, 0);
          resolve(canvas.toDataURL('image/jpeg', 0.95));
        }
      };
      img.src = imageData;
    });
  };

  const extractTextWithMLKit = async (imageData: string): Promise<OCRData> => {
    // Simulate Google ML Kit OCR processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock OCR results based on common receipt patterns
    const mockResults: OCRData = {
      purchaseDate: '2024-01-15',
      storeName: 'Best Buy',
      productKeywords: ['iPhone', '15', 'Pro', '128GB'],
      confidence: 0.85
    };

    // Add premium features for premium users
    if (user?.isPremium) {
      mockResults.serialNumber = 'XYZ123ABC456';
      mockResults.productName = 'Apple iPhone 15 Pro 128GB';
    }

    return mockResults;
  };

  const extractTextWithOpenAI = async (imageData: string): Promise<OCRData> => {
    // Simulate OpenAI Vision API processing
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    return {
      purchaseDate: '2024-01-15',
      storeName: 'Best Buy',
      productKeywords: ['iPhone', '15', 'Pro', '128GB', 'Apple'],
      serialNumber: 'XYZ123ABC456',
      productName: 'Apple iPhone 15 Pro 128GB - Blue Titanium',
      confidence: 0.95
    };
  };

  const processImage = async (imageData: string) => {
    setIsProcessing(true);
    setError(null);
    
    try {
      // Preprocess image
      const processedImage = await preprocessImage(imageData);
      
      // Choose OCR method based on user subscription
      let ocrResult: OCRData;
      if (user?.isPremium) {
        ocrResult = await extractTextWithOpenAI(processedImage);
      } else {
        ocrResult = await extractTextWithMLKit(processedImage);
      }
      
      setOCRData(ocrResult);
    } catch (err) {
      setError('Failed to process image. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const retakePhoto = () => {
    setCapturedImage(null);
    setOCRData(null);
    setError(null);
    startCamera();
  };

  const confirmOCR = () => {
    if (ocrData) {
      onOCRComplete(ocrData);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-hidden">
        <CardContent className="p-0">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b">
            <h3 className="text-lg font-semibold">Scan Receipt</h3>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Camera/File Upload Area */}
          <div className="relative">
            {!capturedImage ? (
              <div className="p-4">
                {isCapturing ? (
                  <div className="relative">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      className="w-full rounded-lg"
                    />
                    <div className="absolute inset-0 pointer-events-none">
                      {/* OCR Guidelines */}
                      <div className="absolute inset-4 border-2 border-white border-dashed rounded-lg">
                        <div className="absolute top-2 left-2 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded">
                          Align receipt within frame
                        </div>
                      </div>
                    </div>
                    <div className="flex justify-center mt-4 space-x-2">
                      <Button onClick={captureImage} className="bg-indigo-600 hover:bg-indigo-700">
                        <Camera className="w-4 h-4 mr-2" />
                        Capture
                      </Button>
                      <Button variant="outline" onClick={stopCamera}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Camera className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h4 className="text-lg font-medium mb-2">Scan Receipt</h4>
                    <p className="text-gray-600 mb-6">
                      Take a photo or upload a receipt to automatically extract warranty information
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                      <Button onClick={startCamera} className="bg-indigo-600 hover:bg-indigo-700">
                        <Camera className="w-4 h-4 mr-2" />
                        Use Camera
                      </Button>
                      <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                        <RotateCw className="w-4 h-4 mr-2" />
                        Upload File
                      </Button>
                    </div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </div>
                )}
              </div>
            ) : (
              <div className="p-4">
                {/* Captured Image */}
                <div className="mb-4">
                  <img
                    src={capturedImage}
                    alt="Captured receipt"
                    className="w-full rounded-lg"
                  />
                </div>

                {/* Processing State */}
                {isProcessing && (
                  <div className="text-center py-4">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto mb-2"></div>
                    <p className="text-sm text-gray-600">
                      {user?.isPremium ? 'Using advanced AI to extract details...' : 'Extracting text from receipt...'}
                    </p>
                  </div>
                )}

                {/* Error State */}
                {error && (
                  <div className="flex items-center space-x-2 p-3 bg-red-50 border border-red-200 rounded-lg mb-4">
                    <AlertCircle className="w-5 h-5 text-red-500" />
                    <p className="text-sm text-red-700">{error}</p>
                  </div>
                )}

                {/* OCR Results */}
                {ocrData && !isProcessing && (
                  <div className="space-y-4">
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <div className="flex items-center space-x-2 mb-3">
                        <Check className="w-5 h-5 text-green-600" />
                        <h4 className="font-medium text-green-900">Extracted Information</h4>
                        <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                          {Math.round(ocrData.confidence * 100)}% confidence
                        </span>
                      </div>
                      
                      <div className="space-y-2 text-sm">
                        {ocrData.productName && (
                          <div>
                            <span className="font-medium">Product:</span> {ocrData.productName}
                          </div>
                        )}
                        {ocrData.storeName && (
                          <div>
                            <span className="font-medium">Store:</span> {ocrData.storeName}
                          </div>
                        )}
                        {ocrData.purchaseDate && (
                          <div>
                            <span className="font-medium">Purchase Date:</span> {ocrData.purchaseDate}
                          </div>
                        )}
                        {ocrData.serialNumber && (
                          <div>
                            <span className="font-medium">Serial Number:</span> {ocrData.serialNumber}
                          </div>
                        )}
                        {ocrData.productKeywords && (
                          <div>
                            <span className="font-medium">Keywords:</span> {ocrData.productKeywords.join(', ')}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Premium Feature Badge */}
                    {!user?.isPremium && (
                      <div className="bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-lg p-3">
                        <p className="text-sm text-yellow-800">
                          💡 Upgrade to Premium for advanced OCR with serial number detection and smart product naming
                        </p>
                      </div>
                    )}

                    <div className="flex space-x-2">
                      <Button variant="outline" onClick={retakePhoto}>
                        <RotateCw className="w-4 h-4 mr-2" />
                        Retake
                      </Button>
                      <Button onClick={confirmOCR} className="bg-indigo-600 hover:bg-indigo-700">
                        <Check className="w-4 h-4 mr-2" />
                        Use This Information
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};