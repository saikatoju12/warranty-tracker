import React, { useState } from 'react';
import { Header } from './components/Header';
import { WarrantyList } from './components/WarrantyList';
import { WarrantyForm } from './components/WarrantyForm';
import { ExpiryBanner } from './components/ExpiryBanner';
import { NotificationBanner } from './components/NotificationBanner';
import { PricingModal } from './components/PricingModal';
import { UpgradePrompt } from './components/UpgradePrompt';
import { PremiumBadge } from './components/PremiumBadge';
import { useAuth } from './contexts/AuthContext';
import { useWarranties } from './hooks/useWarranties';
import { FeatureGate } from './components/FeatureGate';

function App() {
  const { user } = useAuth();
  const { warranties, addWarranty, updateWarranty, deleteWarranty } = useWarranties();
  const [showForm, setShowForm] = useState(false);
  const [editingWarranty, setEditingWarranty] = useState(null);
  const [showPricing, setShowPricing] = useState(false);

  const handleAddWarranty = () => {
    setEditingWarranty(null);
    setShowForm(true);
  };

  const handleEditWarranty = (warranty) => {
    setEditingWarranty(warranty);
    setShowForm(true);
  };

  const handleSubmit = async (warrantyData) => {
    try {
      if (editingWarranty) {
        await updateWarranty(editingWarranty.id, warrantyData);
      } else {
        await addWarranty(warrantyData);
      }
      setShowForm(false);
      setEditingWarranty(null);
    } catch (error) {
      console.error('Failed to save warranty:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NotificationBanner />
      <Header onAddWarranty={handleAddWarranty} onUpgrade={() => setShowPricing(true)} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Upgrade Prompt for Free Users */}
        <FeatureGate feature="advanced-ocr" fallback={
          <UpgradePrompt 
            feature="advanced-ocr" 
            onUpgrade={() => setShowPricing(true)}
          />
        }>
          <div />
        </FeatureGate>

        {/* Premium Status Badge */}
        {user?.isPremium && (
          <div className="mb-6 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <PremiumBadge variant="large" />
              <span className="text-sm text-gray-600">
                All premium features are unlocked
              </span>
            </div>
          </div>
        )}

        {/* Warranty List */}
        <WarrantyList
          warranties={warranties}
          onEdit={handleEditWarranty}
          onDelete={deleteWarranty}
        />
      </main>

      {/* Warranty Form Modal */}
      {showForm && (
        <WarrantyForm
          warranty={editingWarranty}
          onClose={() => setShowForm(false)}
          onSubmit={handleSubmit}
        />
      )}

      {/* Pricing Modal */}
      {showPricing && (
        <PricingModal onClose={() => setShowPricing(false)} />
      )}
    </div>
  );
}

export default App;