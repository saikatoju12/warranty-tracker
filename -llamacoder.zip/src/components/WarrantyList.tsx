import React, { useState } from "react";
import { Trash2, Calendar, ShoppingBag, FileText, ChevronDown, ChevronUp } from "lucide-react";
import { Warranty } from "../types/warranty";

interface WarrantyListProps {
  warranties: Warranty[];
  onDelete: (id: string) => void;
}

export function WarrantyList({ warranties, onDelete }: WarrantyListProps) {
  const [expandedCard, setExpandedCard] = useState<string | null>(null);

  const getStatusColor = (status: Warranty["status"]) => {
    switch (status) {
      case "expired":
        return "bg-gray-100 text-gray-800";
      case "expiring":
        return "bg-yellow-100 text-yellow-800";
      case "active":
        return "bg-green-100 text-green-800";
    }
  };

  const getStatusText = (status: Warranty["status"]) => {
    switch (status) {
      case "expired":
        return "Expired";
      case "expiring":
        return "Expiring Soon";
      case "active":
        return "Active";
    }
  };

  const calculateStatus = (expirationDate: string): Warranty["status"] => {
    const today = new Date();
    const expiration = new Date(expirationDate);
    const daysUntilExpiration = Math.ceil((expiration.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    if (daysUntilExpiration < 0) return "expired";
    if (daysUntilExpiration <= 30) return "expiring";
    return "active";
  };

  const sortedWarranties = [...warranties].sort((a, b) => 
    new Date(a.expirationDate).getTime() - new Date(b.expirationDate).getTime()
  );

  if (warranties.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
          <Calendar className="w-12 h-12 text-gray-400" />
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">No warranties yet</h3>
        <p className="text-gray-600">Add your first warranty to start tracking</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {sortedWarranties.map((warranty) => {
        const status = calculateStatus(warranty.expirationDate);
        const isExpanded = expandedCard === warranty.id;

        return (
          <div
            key={warranty.id}
            className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">{warranty.productName}</h3>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(status)}`}>
                  {getStatusText(status)}
                </span>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center text-sm text-gray-600">
                  <Calendar className="w-4 h-4 mr-2" />
                  Expires: {new Date(warranty.expirationDate).toLocaleDateString()}
                </div>
                {warranty.retailer && (
                  <div className="flex items-center text-sm text-gray-600">
                    <ShoppingBag className="w-4 h-4 mr-2" />
                    {warranty.retailer}
                  </div>
                )}
              </div>

              {warranty.notes && (
                <div className="border-t pt-3">
                  <button
                    onClick={() => setExpandedCard(isExpanded ? null : warranty.id)}
                    className="flex items-center text-sm text-indigo-600 hover:text-indigo-700"
                  >
                    <FileText className="w-4 h-4 mr-1" />
                    Notes
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 ml-1" />
                    ) : (
                      <ChevronDown className="w-4 h-4 ml-1" />
                    )}
                  </button>
                  {isExpanded && (
                    <p className="mt-2 text-sm text-gray-600">{warranty.notes}</p>
                  )}
                </div>
              )}

              <div className="flex justify-end mt-4 pt-4 border-t">
                <button
                  onClick={() => onDelete(warranty.id)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}