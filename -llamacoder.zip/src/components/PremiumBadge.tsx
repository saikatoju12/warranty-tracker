import React from 'react';
import { Crown, Sparkles } from 'lucide-react';
import { Badge } from './ui/badge';
import { useAuth } from '../contexts/AuthContext';

interface PremiumBadgeProps {
  variant?: 'default' | 'small' | 'large';
  showText?: boolean;
}

export const PremiumBadge: React.FC<PremiumBadgeProps> = ({ 
  variant = 'default', 
  showText = true 
}) => {
  const { user } = useAuth();
  
  if (!user?.isPremium) return null;

  const getBadgeClass = () => {
    switch (variant) {
      case 'small':
        return 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white text-xs px-2 py-1';
      case 'large':
        return 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white px-4 py-2';
      default:
        return 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white';
    }
  };

  const getIcon = () => {
    switch (variant) {
      case 'small':
        return <Crown className="w-3 h-3" />;
      case 'large':
        return <Crown className="w-5 h-5" />;
      default:
        return <Crown className="w-4 h-4" />;
    }
  };

  return (
    <Badge className={`${getBadgeClass()} flex items-center space-x-1`}>
      <Sparkles className="w-3 h-3 animate-pulse" />
      {getIcon()}
      {showText && <span>Premium</span>}
    </Badge>
  );
};