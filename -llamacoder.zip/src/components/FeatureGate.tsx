import React from 'react';
import { Lock, Crown } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { PremiumBadge } from './PremiumBadge';
import { useAuth } from '../contexts/AuthContext';

interface FeatureGateProps {
  feature: string;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export const FeatureGate: React.FC<FeatureGateProps> = ({ 
  feature, 
  children, 
  fallback 
}) => {
  const { user } = useAuth();

  const isPremiumFeature = (featureName: string): boolean => {
    const premiumFeatures = [
      'advanced-ocr',
      'email-scanning',
      'unlimited-storage',
      'multiple-profiles',
      'pdf-export',
      'no-ads'
    ];
    return premiumFeatures.includes(featureName);
  };

  const getFeatureDescription = (featureName: string): string => {
    const descriptions: Record<string, string> = {
      'advanced-ocr': 'Advanced OCR with OpenAI Vision for better text extraction',
      'email-scanning': 'Scan receipts directly from your email inbox',
      'unlimited-storage': 'Store unlimited warranties in the cloud',
      'multiple-profiles': 'Share with family members and manage multiple profiles',
      'pdf-export': 'Export your warranties to PDF and CSV formats',
      'no-ads': 'Enjoy an ad-free experience forever'
    };
    return descriptions[featureName] || 'Premium feature';
  };

  if (!isPremiumFeature(feature)) {
    return <>{children}</>;
  }

  if (user?.isPremium) {
    return <>{children}</>;
  }

  if (fallback) {
    return <>{fallback}</>;
  }

  return (
    <Card className="border-dashed border-gray-300 bg-gray-50">
      <CardContent className="p-6 text-center">
        <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Lock className="w-6 h-6 text-indigo-600" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          Premium Feature
        </h3>
        <p className="text-gray-600 mb-4">
          {getFeatureDescription(feature)}
        </p>
        <div className="flex items-center justify-center space-x-2 mb-4">
          <PremiumBadge />
          <span className="text-sm text-gray-500">One-time purchase</span>
        </div>
        <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
          <Crown className="w-4 h-4 mr-2" />
          Upgrade to Premium
        </Button>
      </CardContent>
    </Card>
  );
};