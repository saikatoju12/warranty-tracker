import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '../components/ui/button';
import { WarrantyForm } from '../components/WarrantyForm';
import { useWarranties } from '../hooks/useWarranties';

export const AddWarrantyScreen: React.FC = () => {
  const navigate = useNavigate();
  const { addWarranty } = useWarranties();

  const handleSubmit = async (warrantyData: Omit<any, 'id'>) => {
    try {
      await addWarranty(warrantyData);
      navigate('/home');
    } catch (error) {
      console.error('Failed to add warranty:', error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate('/home')}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Add New Warranty</h1>
          <p className="text-gray-600">Enter warranty details</p>
        </div>
      </div>

      {/* Form */}
      <WarrantyForm
        onClose={() => navigate('/home')}
        onSubmit={handleSubmit}
      />
    </div>
  );
};