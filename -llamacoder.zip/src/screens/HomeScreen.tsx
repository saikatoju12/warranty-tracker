import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, AlertTriangle, Calendar, Package } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { useWarranties } from '../hooks/useWarranties';
import { WarrantyCard } from '../components/WarrantyCard';
import { ExpiryBanner } from '../components/ExpiryBanner';

export const HomeScreen: React.FC = () => {
  const navigate = useNavigate();
  const { warranties, isLoading } = useWarranties();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  const expiringSoon = warranties.filter(w => {
    const daysUntilExpiry = Math.ceil((new Date(w.expirationDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry > 0 && daysUntilExpiry <= 30;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">Manage your warranties</p>
        </div>
        <Button
          onClick={() => navigate('/add-warranty')}
          className="bg-indigo-600 hover:bg-indigo-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Warranty
        </Button>
      </div>

      {/* Expiry Banner */}
      <ExpiryBanner warranties={warranties} />

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Warranties</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{warranties.length}</div>
            <p className="text-xs text-muted-foreground">
              Active warranties
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expiring Soon</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{expiringSoon.length}</div>
            <p className="text-xs text-muted-foreground">
              Within 30 days
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">This Month</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {warranties.filter(w => {
                const purchaseDate = new Date(w.purchaseDate);
                const now = new Date();
                return purchaseDate.getMonth() === now.getMonth() && 
                       purchaseDate.getFullYear() === now.getFullYear();
              }).length}
            </div>
            <p className="text-xs text-muted-foreground">
              New purchases
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Warranties List */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Your Warranties</h2>
        {warranties.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Package className="w-12 h-12 text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No warranties yet</h3>
              <p className="text-gray-600 mb-4">Start tracking your product warranties</p>
              <Button
                onClick={() => navigate('/add-warranty')}
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Warranty
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {warranties.map((warranty) => (
              <WarrantyCard
                key={warranty.id}
                warranty={warranty}
                onClick={() => navigate(`/warranty/${warranty.id}`)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};