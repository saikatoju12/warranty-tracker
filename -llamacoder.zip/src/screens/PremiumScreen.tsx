import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Crown, Check, Star, Zap, Shield, Clock } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { useAuth } from '../contexts/AuthContext';

export const PremiumScreen: React.FC = () => {
  const navigate = useNavigate();
  const { user, updateUser } = useAuth();

  const handleUpgrade = async () => {
    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      await updateUser({ isPremium: true });
    } catch (error) {
      console.error('Failed to upgrade:', error);
    }
  };

  const features = [
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Unlimited Warranties",
      description: "Track unlimited product warranties without any limits"
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Cloud Backup",
      description: "Automatic cloud backup and sync across all your devices"
    },
    {
      icon: <Clock className="w-6 h-6" />,
      title: "Advanced Reminders",
      description: "Customizable reminder schedules and notification channels"
    },
    {
      icon: <Star className="w-6 h-6" />,
      title: "Priority Support",
      description: "Get priority customer support and feature requests"
    }
  ];

  if (user?.isPremium) {
    return (
      <div className="space-y-6">
        <div className="text-center py-12">
          <Crown className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Premium Active!</h1>
          <p className="text-gray-600 mb-6">You have access to all premium features</p>
          <Button onClick={() => navigate('/home')}>
            Continue to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate('/settings')}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Upgrade to Premium</h1>
          <p className="text-gray-600">Unlock all features and get the most out of Warranty Tracker</p>
        </div>
      </div>

      {/* Pricing Card */}
      <Card className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Crown className="w-12 h-12" />
          </div>
          <CardTitle className="text-2xl">Premium Plan</CardTitle>
          <CardDescription className="text-indigo-100">
            One-time purchase, lifetime access
          </CardDescription>
          <div className="mt-4">
            <span className="text-4xl font-bold">$29</span>
            <span className="text-lg">/lifetime</span>
          </div>
        </CardHeader>
        <CardContent>
          <Button
            onClick={handleUpgrade}
            className="w-full bg-white text-indigo-600 hover:bg-gray-100"
            size="lg"
          >
            Upgrade Now
          </Button>
        </CardContent>
      </Card>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {features.map((feature, index) => (
          <Card key={index}>
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-indigo-100 rounded-lg text-indigo-600">
                  {feature.icon}
                </div>
                <CardTitle className="text-lg">{feature.title}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">{feature.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Comparison */}
      <Card>
        <CardHeader>
          <CardTitle>Free vs Premium</CardTitle>
          <CardDescription>See what you get with Premium</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-gray-900 mb-3">Free Plan</h4>
              <ul className="space-y-2">
                <li className="flex items-center text-sm">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Up to 10 warranties
                </li>
                <li className="flex items-center text-sm">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Basic reminders
                </li>
                <li className="flex items-center text-sm">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Local storage only
                </li>
                <li className="flex items-center text-sm text-gray-400">
                  <span className="w-4 h-4 mr-2">×</span>
                  Cloud sync
                </li>
                <li className="flex items-center text-sm text-gray-400">
                  <span className="w-4 h-4 mr-2">×</span>
                  Priority support
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 mb-3">Premium Plan</h4>
              <ul className="space-y-2">
                <li className="flex items-center text-sm">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Unlimited warranties
                </li>
                <li className="flex items-center text-sm">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Advanced reminders
                </li>
                <li className="flex items-center text-sm">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Cloud backup & sync
                </li>
                <li className="flex items-center text-sm">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Priority support
                </li>
                <li className="flex items-center text-sm">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Early access to features
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* FAQ */}
      <Card>
        <CardHeader>
          <CardTitle>Frequently Asked Questions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-medium text-gray-900 mb-2">Is this a one-time payment?</h4>
            <p className="text-sm text-gray-600">Yes! Premium is a one-time purchase of $29 for lifetime access.</p>
          </div>
          <div>
            <h4 className="font-medium text-gray-900 mb-2">Can I cancel anytime?</h4>
            <p className="text-sm text-gray-600">Since it's a one-time purchase, there's no subscription to cancel.</p>
          </div>
          <div>
            <h4 className="font-medium text-gray-900 mb-2">What if I'm not satisfied?</h4>
            <p className="text-sm text-gray-600">We offer a 30-day money-back guarantee if you're not completely satisfied.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};