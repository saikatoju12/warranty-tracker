import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export const SplashScreen: React.FC = () => {
  const navigate = useNavigate();
  const { user, isFirstTime } = useAuth();

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!user) {
        if (isFirstTime) {
          navigate('/onboarding');
        } else {
          navigate('/login');
        }
      } else {
        navigate('/home');
      }
    }, 2000);

    return () => clearTimeout(timer);
  }, [navigate, user, isFirstTime]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 to-purple-700 flex items-center justify-center">
      <div className="text-center">
        <div className="mb-8">
          <Shield className="w-24 h-24 text-white mx-auto animate-pulse" />
        </div>
        <h1 className="text-4xl font-bold text-white mb-2">Warranty Tracker</h1>
        <p className="text-indigo-100">Never miss an expiration date</p>
      </div>
    </div>
  );
};