import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Calendar, Bell, Lock } from 'lucide-react';
import { Button } from '../components/ui/button';

export const OnboardingScreen: React.FC = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = React.useState(0);

  const steps = [
    {
      icon: <Shield className="w-16 h-16 text-indigo-600" />,
      title: "Track Your Warranties",
      description: "Keep all your product warranties in one place and never lose important information again."
    },
    {
      icon: <Calendar className="w-16 h-16 text-indigo-600" />,
      title: "Smart Reminders",
      description: "Get notified before your warranties expire so you can make claims on time."
    },
    {
      icon: <Bell className="w-16 h-16 text-indigo-600" />,
      title: "Document Storage",
      description: "Upload receipts and warranty documents for safe keeping and easy access."
    },
    {
      icon: <Lock className="w-16 h-16 text-indigo-600" />,
      title: "Secure & Private",
      description: "Your data is encrypted and stored locally. We never share your information."
    }
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      localStorage.setItem('hasSeenOnboarding', 'true');
      navigate('/signup');
    }
  };

  const handleSkip = () => {
    localStorage.setItem('hasSeenOnboarding', 'true');
    navigate('/signup');
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Progress Bar */}
      <div className="pt-8 px-6">
        <div className="flex justify-center space-x-2">
          {steps.map((_, index) => (
            <div
              key={index}
              className={`h-2 w-8 rounded-full transition-colors ${
                index === currentStep ? 'bg-indigo-600' : 'bg-gray-200'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
        <div className="mb-8">
          {steps[currentStep].icon}
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-4 text-center">
          {steps[currentStep].title}
        </h2>
        <p className="text-lg text-gray-600 text-center max-w-md">
          {steps[currentStep].description}
        </p>
      </div>

      {/* Actions */}
      <div className="px-6 pb-8">
        <div className="flex space-x-4">
          <Button
            variant="outline"
            onClick={handleSkip}
            className="flex-1"
          >
            Skip
          </Button>
          <Button
            onClick={handleNext}
            className="flex-1 bg-indigo-600 hover:bg-indigo-700"
          >
            {currentStep === steps.length - 1 ? 'Get Started' : 'Next'}
          </Button>
        </div>
      </div>
    </div>
  );
};