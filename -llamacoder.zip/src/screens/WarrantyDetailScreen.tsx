import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Edit, Trash2, Upload, Calendar, Store, FileText } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { useWarranties } from '../hooks/useWarranties';
import { Warranty } from '../types/warranty';

export const WarrantyDetailScreen: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { warranties, deleteWarranty } = useWarranties();
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const warranty = warranties.find(w => w.id === id);

  if (!warranty) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <h3 className="text-lg font-medium text-gray-900 mb-2">Warranty not found</h3>
          <Button onClick={() => navigate('/home')}>Go Back</Button>
        </div>
      </div>
    );
  }

  const handleDelete = async () => {
    try {
      await deleteWarranty(warranty.id);
      navigate('/home');
    } catch (error) {
      console.error('Failed to delete warranty:', error);
    }
  };

  const daysUntilExpiry = Math.ceil((new Date(warranty.expirationDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
  const isExpired = daysUntilExpiry < 0;
  const isExpiringSoon = daysUntilExpiry > 0 && daysUntilExpiry <= 30;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/home')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{warranty.productName}</h1>
            <p className="text-gray-600">Warranty Details</p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            onClick={() => navigate(`/upload-documents/${warranty.id}`)}
          >
            <Upload className="w-4 h-4 mr-2" />
            Documents
          </Button>
          <Button
            variant="outline"
            onClick={() => navigate(`/edit-warranty/${warranty.id}`)}
          >
            <Edit className="w-4 h-4 mr-2" />
            Edit
          </Button>
          <Button
            variant="destructive"
            onClick={() => setShowDeleteConfirm(true)}
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Delete
          </Button>
        </div>
      </div>

      {/* Status Card */}
      <Card className={`border-l-4 ${
        isExpired ? 'border-l-red-500' : 
        isExpiringSoon ? 'border-l-orange-500' : 
        'border-l-green-500'
      }`}>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Warranty Status</span>
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
              isExpired ? 'bg-red-100 text-red-800' : 
              isExpiringSoon ? 'bg-orange-100 text-orange-800' : 
              'bg-green-100 text-green-800'
            }`}>
              {isExpired ? 'Expired' : isExpiringSoon ? 'Expiring Soon' : 'Active'}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">Purchase Date</p>
              <p className="font-medium">{new Date(warranty.purchaseDate).toLocaleDateString()}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Expiration Date</p>
              <p className="font-medium">{new Date(warranty.expirationDate).toLocaleDateString()}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Warranty Duration</p>
              <p className="font-medium">{warranty.warrantyDuration} year(s)</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Days Until Expiry</p>
              <p className="font-medium">{isExpired ? 'Expired' : `${daysUntilExpiry} days`}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Details Card */}
      <Card>
        <CardHeader>
          <CardTitle>Warranty Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <Store className="w-4 h-4 text-gray-400" />
            <div>
              <p className="text-sm text-gray-600">Retailer</p>
              <p className="font-medium">{warranty.retailer}</p>
            </div>
          </div>
          
          {warranty.notes && (
            <div className="flex items-start space-x-2">
              <FileText className="w-4 h-4 text-gray-400 mt-1" />
              <div>
                <p className="text-sm text-gray-600">Notes</p>
                <p className="font-medium whitespace-pre-wrap">{warranty.notes}</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Documents Card */}
      <Card>
        <CardHeader>
          <CardTitle>Documents</CardTitle>
          <CardDescription>
            Receipts, warranty certificates, and other important files
          </CardDescription>
        </CardHeader>
        <CardContent>
          {warranty.documents && warranty.documents.length > 0 ? (
            <div className="space-y-2">
              {warranty.documents.map((doc, index) => (
                <div key={index} className="flex items-center justify-between p-2 border rounded">
                  <span className="text-sm">{doc}</span>
                  <Button variant="ghost" size="sm">View</Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-4">
              <p className="text-gray-500 mb-2">No documents uploaded</p>
              <Button
                variant="outline"
                onClick={() => navigate(`/upload-documents/${warranty.id}`)}
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload Documents
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Delete Warranty</h3>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this warranty? This action cannot be undone.
            </p>
            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={handleDelete}
                className="flex-1"
              >
                Delete
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};