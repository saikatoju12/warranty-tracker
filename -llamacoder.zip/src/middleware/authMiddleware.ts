// Authentication middleware for additional security checks

import { SecurityValidator, RateLimiter } from '../utils/securityUtils';

export class AuthMiddleware {
  // Validate user session
  static validateSession(user: any): boolean {
    if (!user) return false;
    
    // Check if user is authenticated
    if (!user.uid) return false;
    
    // Check if email is verified (optional)
    if (user.email && !user.emailVerified) {
      console.warn('Unverified email access attempt');
    }
    
    return true;
  }

  // Rate limiting for sensitive operations
  static checkRateLimit(userId: string, operation: string): boolean {
    const key = `${userId}-${operation}`;
    return RateLimiter.isAllowed(key, 5, 60000); // 5 attempts per minute
  }

  // Validate data before sending to Firestore
  static validateWarrantyData(data: any): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!SecurityValidator.isValidProductName(data.productName)) {
      errors.push('Invalid product name');
    }

    if (!SecurityValidator.isValidDate(data.purchaseDate)) {
      errors.push('Invalid purchase date');
    }

    if (!SecurityValidator.isValidDate(data.expirationDate)) {
      errors.push('Invalid expiration date');
    }

    if (data.purchaseDate >= data.expirationDate) {
      errors.push('Expiration date must be after purchase date');
    }

    if (!SecurityValidator.isValidRetailer(data.retailer)) {
      errors.push('Invalid retailer name');
    }

    if (!SecurityValidator.isValidWarrantyDuration(data.warrantyDuration)) {
      errors.push('Invalid warranty duration');
    }

    if (!SecurityValidator.isValidWarrantyStatus(data.status)) {
      errors.push('Invalid warranty status');
    }

    if (data.notes && !SecurityValidator.isValidNotes(data.notes)) {
      errors.push('Notes too long');
    }

    if (data.serialNumber && !SecurityValidator.isValidSerialNumber(data.serialNumber)) {
      errors.push('Invalid serial number');
    }

    if (data.purchaseAmount && !SecurityValidator.isValidPurchaseAmount(data.purchaseAmount)) {
      errors.push('Invalid purchase amount');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  // Sanitize data before storage
  static sanitizeData(data: any): any {
    const sanitized = { ...data };

    // Sanitize string fields
    if (sanitized.productName) {
      sanitized.productName = SecurityValidator.sanitizeInput(sanitized.productName);
    }

    if (sanitized.retailer) {
      sanitized.retailer = SecurityValidator.sanitizeInput(sanitized.retailer);
    }

    if (sanitized.notes) {
      sanitized.notes = SecurityValidator.sanitizeInput(sanitized.notes);
    }

    if (sanitized.serialNumber) {
      sanitized.serialNumber = SecurityValidator.sanitizeInput(sanitized.serialNumber);
    }

    return sanitized;
  }

  // Validate file uploads
  static validateFileUpload(file: File): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!SecurityValidator.isValidImageType(file.type)) {
      errors.push('Invalid file type. Only JPEG, PNG, and WebP are allowed.');
    }

    if (!SecurityValidator.isValidFileSize(file.size)) {
      errors.push('File too large. Maximum size is 10MB.');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}