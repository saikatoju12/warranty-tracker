export interface User {
  id: string;
  email: string;
  name: string;
  avatar: string | null;
  isPremium: boolean;
  createdAt: string;
}