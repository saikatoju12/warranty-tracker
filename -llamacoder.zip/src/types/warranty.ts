export interface Warranty {
  id: string;
  productName: string;
  purchaseDate: string;
  expirationDate: string;
  warrantyDuration: string;
  retailer: string;
  notes: string;
  documents: string[];
  userId: string;
  createdAt: string;
  updatedAt: string;
}