import React, { Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { LoadingScreen } from './components/LoadingScreen';
import { SplashScreen } from './screens/SplashScreen';
import { OnboardingScreen } from './screens/OnboardingScreen';
import { LoginScreen } from './screens/LoginScreen';
import { SignupScreen } from './screens/SignupScreen';
import { MainLayout } from './layouts/MainLayout';
import { HomeScreen } from './screens/HomeScreen';
import { AddWarrantyScreen } from './screens/AddWarrantyScreen';
import { WarrantyDetailScreen } from './screens/WarrantyDetailScreen';
import { UploadDocumentsScreen } from './screens/UploadDocumentsScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { PremiumScreen } from './screens/PremiumScreen';

// Protected Route Component
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return <LoadingScreen />;
  }
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

// Public Route Component (redirects to home if authenticated)
const PublicRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return <LoadingScreen />;
  }
  
  if (user) {
    return <Navigate to="/home" replace />;
  }
  
  return <>{children}</>;
};

// App Routes Component
const AppRoutes: React.FC = () => {
  const { isFirstTime, isLoading } = useAuth();
  
  if (isLoading) {
    return <SplashScreen />;
  }
  
  return (
    <Routes>
      {/* Splash and Onboarding */}
      <Route path="/splash" element={<SplashScreen />} />
      <Route 
        path="/onboarding" 
        element={
          <PublicRoute>
            <OnboardingScreen />
          </PublicRoute>
        } 
      />
      
      {/* Auth Routes */}
      <Route 
        path="/login" 
        element={
          <PublicRoute>
            <LoginScreen />
          </PublicRoute>
        } 
      />
      <Route 
        path="/signup" 
        element={
          <PublicRoute>
            <SignupScreen />
          </PublicRoute>
        } 
      />
      
      {/* Protected Routes */}
      <Route 
        path="/" 
        element={
          <ProtectedRoute>
            <MainLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/home" replace />} />
        <Route path="home" element={<HomeScreen />} />
        <Route path="add-warranty" element={<AddWarrantyScreen />} />
        <Route path="warranty/:id" element={<WarrantyDetailScreen />} />
        <Route path="upload-documents/:id" element={<UploadDocumentsScreen />} />
        <Route path="settings" element={<SettingsScreen />} />
        <Route path="premium" element={<PremiumScreen />} />
      </Route>
      
      {/* Fallback */}
      <Route path="*" element={<Navigate to="/home" replace />} />
    </Routes>
  );
};

// Main App Component
export const App: React.FC = () => {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <Suspense fallback={<LoadingScreen />}>
            <AppRoutes />
          </Suspense>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
};

export default App;