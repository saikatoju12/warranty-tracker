import React, { useState, useEffect, createContext, useContext, ReactNode } from "react";

// Types
export interface User {
  uid: string;
  name: string;
  email: string;
  photoUrl: string;
  authProvider: string;
  isPremium: boolean;
  createdAt: Date;
  lastLoginAt: Date;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isInitialized: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signUpWithEmail: (email: string, password: string, name: string) => Promise<void>;
  signOut: () => Promise<void>;
  deleteAccount: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user storage
const STORAGE_KEY = "warranty_tracker_user";
const USER_DATA_KEY = "warranty_tracker_user_data";

// Generate mock user data
const generateMockUser = (email: string, name: string, provider: string): User => {
  const now = new Date();
  return {
    uid: `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    name: name || email.split("@")[0],
    email,
    photoUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`,
    authProvider: provider,
    isPremium: false,
    createdAt: now,
    lastLoginAt: now
  };
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);

  // Auth state listener - monitors localStorage changes across tabs
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) {
        if (e.newValue) {
          try {
            const userData = JSON.parse(e.newValue);
            userData.createdAt = new Date(userData.createdAt);
            userData.lastLoginAt = new Date(userData.lastLoginAt);
            setUser(userData);
          } catch (error) {
            console.error("Error parsing user data from storage event:", error);
            setUser(null);
          }
        } else {
          setUser(null);
        }
      }
    };

    // Add storage event listener
    window.addEventListener("storage", handleStorageChange);

    return () => {
      window.removeEventListener("storage", handleStorageChange);
    };
  }, []);

  // Initialize auth state from localStorage
  useEffect(() => {
    const initializeAuth = () => {
      try {
        const storedUser = localStorage.getItem(STORAGE_KEY);
        if (storedUser) {
          const userData = JSON.parse(storedUser);
          // Convert string dates back to Date objects
          userData.createdAt = new Date(userData.createdAt);
          userData.lastLoginAt = new Date(userData.lastLoginAt);
          setUser(userData);
        }
      } catch (error) {
        console.error("Error loading user from storage:", error);
        localStorage.removeItem(STORAGE_KEY);
      } finally {
        setIsInitialized(true);
      }
    };

    initializeAuth();
  }, []);

  // Save user to localStorage whenever it changes
  useEffect(() => {
    if (user) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }, [user]);

  const signInWithGoogle = async () => {
    setIsLoading(true);
    try {
      // Simulate Google OAuth with mock data
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockUser = generateMockUser(
        `user${Math.floor(Math.random() * 1000)}@gmail.com`,
        `Google User ${Math.floor(Math.random() * 1000)}`,
        "google"
      );
      
      setUser(mockUser);
    } catch (error) {
      console.error("Google sign in error:", error);
      throw new Error("Failed to sign in with Google");
    } finally {
      setIsLoading(false);
    }
  };

  const signInWithEmail = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      // Simulate email authentication
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if user exists in localStorage
      const storedUser = localStorage.getItem(STORAGE_KEY);
      if (storedUser) {
        const userData = JSON.parse(storedUser);
        if (userData.email === email) {
          userData.lastLoginAt = new Date();
          setUser(userData);
          return;
        }
      }
      
      throw new Error("Invalid email or password");
    } catch (error) {
      console.error("Email sign in error:", error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const signUpWithEmail = async (email: string, password: string, name: string) => {
    setIsLoading(true);
    try {
      // Simulate email registration
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if user already exists
      const storedUser = localStorage.getItem(STORAGE_KEY);
      if (storedUser) {
        const userData = JSON.parse(storedUser);
        if (userData.email === email) {
          throw new Error("User already exists");
        }
      }
      
      const newUser = generateMockUser(email, name, "email");
      setUser(newUser);
    } catch (error) {
      console.error("Email sign up error:", error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const signOut = async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      setUser(null);
      // Clear any session-specific data
      sessionStorage.clear();
    } catch (error) {
      console.error("Sign out error:", error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const deleteAccount = async () => {
    setIsLoading(true);
    try {
      if (!user) {
        throw new Error("No user to delete");
      }

      // GDPR compliance: Create deletion record
      const deletionRecord = {
        userId: user.uid,
        email: user.email,
        deletionDate: new Date().toISOString(),
        deletionReason: "User requested account deletion",
        dataDeleted: {
          userProfile: true,
          warranties: true,
          settings: true,
          sessions: true
        }
      };

      // Store deletion record for compliance (in real app, this would go to secure backend)
      const deletionRecords = JSON.parse(localStorage.getItem("deletion_records") || "[]");
      deletionRecords.push(deletionRecord);
      localStorage.setItem("deletion_records", JSON.stringify(deletionRecords));

      // Delete all user data
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(USER_DATA_KEY);
      localStorage.removeItem("warranties");
      localStorage.removeItem("user_preferences");
      localStorage.removeItem("user_settings");

      // Clear session data
      sessionStorage.clear();

      // Clear any indexedDB data for this user
      if ("indexedDB" in window) {
        const databases = await indexedDB.databases();
        for (const db of databases) {
          if (db.name && db.name.includes(user.uid)) {
            indexedDB.deleteDatabase(db.name);
          }
        }
      }

      // Clear service worker cache if exists
      if ("caches" in window) {
        const cacheNames = await caches.keys();
        for (const cacheName of cacheNames) {
          if (cacheName.includes(user.uid)) {
            await caches.delete(cacheName);
          }
        }
      }

      setUser(null);
    } catch (error) {
      console.error("Account deletion error:", error);
      throw new Error("Failed to delete account. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const value: AuthContextType = {
    user,
    isLoading,
    isInitialized,
    signInWithGoogle,
    signInWithEmail,
    signUpWithEmail,
    signOut,
    deleteAccount
  };

  return React.createElement(
    AuthContext.Provider,
    { value },
    children
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}