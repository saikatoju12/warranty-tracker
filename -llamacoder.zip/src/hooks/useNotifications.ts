import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Warranty } from '../types/warranty';
import { useToast } from './useToast';

interface NotificationPreferences {
  pushEnabled: boolean;
  emailEnabled: boolean;
  reminderDays: number[];
  reminderTime: string;
  expiredReminderEnabled: boolean;
}

export const useNotifications = () => {
  const { user } = useAuth();
  const { addToast } = useToast();
  const [preferences, setPreferences] = useState<NotificationPreferences | null>(null);
  const [lastCheck, setLastCheck] = useState<Date | null>(null);

  useEffect(() => {
    loadPreferences();
    checkForExpiringWarranties();
  }, []);

  const loadPreferences = () => {
    if (user) {
      const stored = localStorage.getItem(`notificationPrefs_${user.id}`);
      if (stored) {
        setPreferences(JSON.parse(stored));
      } else {
        // Default preferences
        const defaults: NotificationPreferences = {
          pushEnabled: true,
          emailEnabled: false,
          reminderDays: [7, 30],
          reminderTime: '09:00',
          expiredReminderEnabled: true
        };
        setPreferences(defaults);
        localStorage.setItem(`notificationPrefs_${user.id}`, JSON.stringify(defaults));
      }
    }
  };

  const checkForExpiringWarranties = useCallback(async () => {
    if (!user || !preferences) return;

    const now = new Date();
    const today = now.toISOString().split('T')[0];
    
    // Check if we've already checked today
    if (lastCheck && lastCheck.toDateString() === now.toDateString()) {
      return;
    }

    try {
      // Get user's warranties
      const stored = localStorage.getItem('warranties');
      if (!stored) return;

      const allWarranties: Warranty[] = JSON.parse(stored);
      const userWarranties = allWarranties.filter(w => w.userId === user.id);

      // Check for expiring warranties
      const expiringWarranties = userWarranties.filter(warranty => {
        const expirationDate = new Date(warranty.expirationDate);
        const daysUntilExpiration = Math.ceil((expirationDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
        
        return preferences.reminderDays.includes(daysUntilExpiration) || 
               (daysUntilExpiration < 0 && preferences.expiredReminderEnabled);
      });

      // Send notifications
      for (const warranty of expiringWarranties) {
        await sendNotification(warranty);
      }

      setLastCheck(now);
    } catch (error) {
      console.error('Error checking warranties:', error);
    }
  }, [user, preferences, lastCheck]);

  const sendNotification = async (warranty: Warranty) => {
    if (!preferences) return;

    const expirationDate = new Date(warranty.expirationDate);
    const now = new Date();
    const daysUntilExpiration = Math.ceil((expirationDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    let title: string;
    let body: string;
    let icon: string;

    if (daysUntilExpiration === 0) {
      title = 'Warranty Expires Today!';
      body = `Your ${warranty.productName} warranty expires today. Take action now!`;
      icon = '⚠️';
    } else if (daysUntilExpiration > 0) {
      title = `Warranty Expires in ${daysUntilExpiration} Days`;
      body = `Your ${warranty.productName} warranty from ${warranty.retailer} expires on ${warranty.expirationDate}`;
      icon = '⏰';
    } else {
      title = 'Warranty Expired';
      body = `Your ${warranty.productName} warranty expired ${Math.abs(daysUntilExpiration)} days ago`;
      icon = '❌';
    }

    // Send push notification
    if (preferences.pushEnabled && 'Notification' in window && Notification.permission === 'granted') {
      new Notification(title, {
        body,
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        tag: `warranty-${warranty.id}`,
        requireInteraction: true,
        actions: [
          {
            action: 'view',
            title: 'View Warranty'
          },
          {
            action: 'dismiss',
            title: 'Dismiss'
          }
        ]
      });
    }

    // Send email notification (mock implementation)
    if (preferences.emailEnabled) {
      await sendEmailNotification(warranty, title, body);
    }

    // Show in-app toast
    addToast({
      title,
      description: body,
      type: daysUntilExpiration <= 0 ? 'error' : 'warning',
      duration: 10000
    });
  };

  const sendEmailNotification = async (warranty: Warranty, title: string, body: string) => {
    // Mock email sending - in production, this would call your backend
    console.log('Email notification:', {
      to: user?.email,
      subject: title,
      body,
      warranty
    });

    // Store email in sent notifications to prevent duplicates
    const sentEmails = JSON.parse(localStorage.getItem('sentEmails') || '{}');
    const key = `${warranty.id}-${new Date().toDateString()}`;
    
    if (!sentEmails[key]) {
      sentEmails[key] = true;
      localStorage.setItem('sentEmails', JSON.stringify(sentEmails));
    }
  };

  const scheduleNotification = (warranty: Warranty, daysBefore: number) => {
    const expirationDate = new Date(warranty.expirationDate);
    const notificationDate = new Date(expirationDate);
    notificationDate.setDate(notificationDate.getDate() - daysBefore);

    const now = new Date();
    if (notificationDate > now) {
      const timeUntilNotification = notificationDate.getTime() - now.getTime();
      
      setTimeout(() => {
        sendNotification(warranty);
      }, timeUntilNotification);
    }
  };

  const testNotification = () => {
    if (!preferences?.pushEnabled) {
      addToast({
        title: 'Notifications Disabled',
        description: 'Enable push notifications to test',
        type: 'error'
      });
      return;
    }

    if ('Notification' in window) {
      if (Notification.permission === 'granted') {
        new Notification('Test Notification', {
          body: 'This is a test notification from Warranty Tracker',
          icon: '/favicon.ico',
          badge: '/favicon.ico'
        });
        
        addToast({
          title: 'Test Notification Sent',
          description: 'Check your browser notifications',
          type: 'success'
        });
      } else {
        addToast({
          title: 'Permission Required',
          description: 'Allow browser notifications to receive reminders',
          type: 'error'
        });
      }
    }
  };

  return {
    preferences,
    checkForExpiringWarranties,
    sendNotification,
    scheduleNotification,
    testNotification,
    loadPreferences
  };
};