import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from './useToast';

interface PremiumPurchase {
  id: string;
  userId: string;
  plan: 'premium';
  amount: number;
  currency: string;
  platform: 'ios' | 'android' | 'web';
  purchaseDate: string;
  receiptData?: string;
  transactionId?: string;
}

export const usePremium = () => {
  const { user, updateUser } = useAuth();
  const { addToast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [purchases, setPurchases] = useState<PremiumPurchase[]>([]);

  useEffect(() => {
    if (user) {
      loadPurchases();
    }
  }, [user]);

  const loadPurchases = async () => {
    try {
      // Load from Firestore or local storage
      const stored = localStorage.getItem(`purchases_${user?.id}`);
      if (stored) {
        setPurchases(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Error loading purchases:', error);
    }
  };

  const purchasePremium = async (plan: 'premium') => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    setIsProcessing(true);
    
    try {
      // Detect platform
      const platform = detectPlatform();
      let purchaseData: PremiumPurchase;

      switch (platform) {
        case 'ios':
          purchaseData = await handleIOSPurchase(plan);
          break;
        case 'android':
          purchaseData = await handleAndroidPurchase(plan);
          break;
        case 'web':
          purchaseData = await handleWebPurchase(plan);
          break;
        default:
          throw new Error('Unsupported platform');
      }

      // Save purchase
      await savePurchase(purchaseData);
      
      // Update user premium status
      await updateUser({ isPremium: true });
      
      addToast({
        title: 'Purchase Successful!',
        description: 'Welcome to Premium! All features are now unlocked.',
        type: 'success'
      });

      return purchaseData;
    } catch (error) {
      addToast({
        title: 'Purchase Failed',
        description: error instanceof Error ? error.message : 'Failed to complete purchase',
        type: 'error'
      });
      throw error;
    } finally {
      setIsProcessing(false);
    }
  };

  const restorePurchase = async () => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    setIsProcessing(true);
    
    try {
      const platform = detectPlatform();
      let restored = false;

      switch (platform) {
        case 'ios':
          restored = await restoreIOSPurchase();
          break;
        case 'android':
          restored = await restoreAndroidPurchase();
          break;
        case 'web':
          restored = await restoreWebPurchase();
          break;
      }

      if (restored) {
        await updateUser({ isPremium: true });
        addToast({
          title: 'Purchase Restored',
          description: 'Your Premium features have been restored.',
          type: 'success'
        });
      } else {
        addToast({
          title: 'No Purchase Found',
          description: 'No previous Premium purchase found.',
          type: 'error'
        });
      }
    } catch (error) {
      addToast({
        title: 'Restore Failed',
        description: 'Failed to restore purchase. Please contact support.',
        type: 'error'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const detectPlatform = (): 'ios' | 'android' | 'web' => {
    const userAgent = navigator.userAgent.toLowerCase();
    
    if (/iphone|ipad|ipod/.test(userAgent)) {
      return 'ios';
    } else if (/android/.test(userAgent)) {
      return 'android';
    } else {
      return 'web';
    }
  };

  const handleIOSPurchase = async (plan: 'premium'): Promise<PremiumPurchase> => {
    // Mock iOS In-App Purchase
    // In production, this would use StoreKit 2
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simulate successful iOS purchase
        const purchase: PremiumPurchase = {
          id: `ios_${Date.now()}`,
          userId: user!.id,
          plan,
          amount: 19.99,
          currency: 'USD',
          platform: 'ios',
          purchaseDate: new Date().toISOString(),
          receiptData: 'mock_ios_receipt',
          transactionId: `ios_tx_${Date.now()}`
        };
        resolve(purchase);
      }, 2000);
    });
  };

  const handleAndroidPurchase = async (plan: 'premium'): Promise<PremiumPurchase> => {
    // Mock Android Google Play Billing
    // In production, this would use Google Play Billing API
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simulate successful Android purchase
        const purchase: PremiumPurchase = {
          id: `android_${Date.now()}`,
          userId: user!.id,
          plan,
          amount: 19.99,
          currency: 'USD',
          platform: 'android',
          purchaseDate: new Date().toISOString(),
          receiptData: 'mock_android_receipt',
          transactionId: `android_tx_${Date.now()}`
        };
        resolve(purchase);
      }, 2000);
    });
  };

  const handleWebPurchase = async (plan: 'premium'): Promise<PremiumPurchase> => {
    // Mock Stripe payment for web
    // In production, this would integrate with Stripe or similar
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simulate successful web purchase
        const purchase: PremiumPurchase = {
          id: `web_${Date.now()}`,
          userId: user!.id,
          plan,
          amount: 19.99,
          currency: 'USD',
          platform: 'web',
          purchaseDate: new Date().toISOString(),
          transactionId: `web_tx_${Date.now()}`
        };
        resolve(purchase);
      }, 2000);
    });
  };

  const restoreIOSPurchase = async (): Promise<boolean> => {
    // Mock iOS restore
    return new Promise((resolve) => {
      setTimeout(() => {
        // Check for existing iOS purchases
        const hasPurchase = localStorage.getItem(`ios_purchase_${user?.id}`);
        resolve(!!hasPurchase);
      }, 1000);
    });
  };

  const restoreAndroidPurchase = async (): Promise<boolean> => {
    // Mock Android restore
    return new Promise((resolve) => {
      setTimeout(() => {
        // Check for existing Android purchases
        const hasPurchase = localStorage.getItem(`android_purchase_${user?.id}`);
        resolve(!!hasPurchase);
      }, 1000);
    });
  };

  const restoreWebPurchase = async (): Promise<boolean> => {
    // Mock web restore
    return new Promise((resolve) => {
      setTimeout(() => {
        // Check for existing web purchases
        const hasPurchase = localStorage.getItem(`web_purchase_${user?.id}`);
        resolve(!!hasPurchase);
      }, 1000);
    });
  };

  const savePurchase = async (purchase: PremiumPurchase) => {
    // Save to local storage (in production, save to Firestore)
    const updatedPurchases = [...purchases, purchase];
    setPurchases(updatedPurchases);
    localStorage.setItem(`purchases_${user?.id}`, JSON.stringify(updatedPurchases));
    
    // Save platform-specific receipt
    localStorage.setItem(`${purchase.platform}_purchase_${user?.id}`, 'true');
  };

  const validatePurchase = async (purchase: PremiumPurchase): Promise<boolean> => {
    // In production, validate receipt with platform servers
    // For now, just check if purchase exists
    return purchases.some(p => p.id === purchase.id);
  };

  const cancelSubscription = async () => {
    // For one-time purchase, this would be a refund request
    // Implementation depends on platform policies
    addToast({
      title: 'Contact Support',
      description: 'Please contact support for refund requests.',
      type: 'info'
    });
  };

  return {
    purchasePremium,
    restorePurchase,
    cancelSubscription,
    validatePurchase,
    isProcessing,
    purchases,
    isPremium: user?.isPremium || false
  };
};