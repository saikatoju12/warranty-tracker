import { useState, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { OCRProcessor, OCRResult } from '../utils/ocrUtils';

export const useOCR = () => {
  const { user } = useAuth();
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const processImage = useCallback(async (imageData: string): Promise<OCRResult> => {
    setIsProcessing(true);
    setError(null);
    
    try {
      // Preprocess image for better OCR
      const processedImage = await OCRProcessor.preprocessImage(imageData);
      
      // Choose OCR method based on user subscription
      let result: OCRResult;
      if (user?.isPremium) {
        result = await OCRProcessor.processWithOpenAI(processedImage);
      } else {
        result = await OCRProcessor.processWithMLKit(processedImage);
      }
      
      return result;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to process image';
      setError(errorMessage);
      throw err;
    } finally {
      setIsProcessing(false);
    }
  }, [user?.isPremium]);

  return {
    processImage,
    isProcessing,
    error,
    clearError: () => setError(null)
  };
};