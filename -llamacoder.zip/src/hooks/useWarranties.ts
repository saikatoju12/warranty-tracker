import { useState, useEffect } from "react";
import { Warranty } from "../types/warranty";
import { warrantyStorage } from "../utils/warrantyStorage";

export function useWarranties() {
  const [warranties, setWarranties] = useState<Warranty[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadWarranties = async () => {
      try {
        const stored = await warrantyStorage.getAll();
        setWarranties(stored.sort((a, b) => 
          new Date(a.expirationDate).getTime() - new Date(b.expirationDate).getTime()
        ));
      } catch (error) {
        console.error("Failed to load warranties:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadWarranties();
  }, []);

  const addWarranty = async (warranty: Omit<Warranty, "id">) => {
    const newWarranty: Warranty = {
      ...warranty,
      id: crypto.randomUUID(),
    };
    
    await warrantyStorage.save(newWarranty);
    setWarranties(prev => [...prev, newWarranty].sort((a, b) => 
      new Date(a.expirationDate).getTime() - new Date(b.expirationDate).getTime()
    ));
  };

  const deleteWarranty = async (id: string) => {
    await warrantyStorage.delete(id);
    setWarranties(prev => prev.filter(w => w.id !== id));
  };

  return {
    warranties,
    addWarranty,
    deleteWarranty,
    isLoading,
  };
}