export class NotificationScheduler {
  private static instance: NotificationScheduler;
  private scheduledJobs: Map<string, NodeJS.Timeout> = new Map();

  static getInstance(): NotificationScheduler {
    if (!NotificationScheduler.instance) {
      NotificationScheduler.instance = new NotificationScheduler();
    }
    return NotificationScheduler.instance;
  }

  scheduleWarrantyReminder(warrantyId: string, expirationDate: string, reminderDays: number[], userId: string) {
    // Clear existing jobs for this warranty
    this.clearWarrantyJobs(warrantyId);

    const expiration = new Date(expirationDate);
    const now = new Date();

    reminderDays.forEach(daysBefore => {
      const reminderDate = new Date(expiration);
      reminderDate.setDate(reminderDate.getDate() - daysBefore);

      if (reminderDate > now) {
        const timeUntilReminder = reminderDate.getTime() - now.getTime();
        
        const jobId = `${warrantyId}-${daysBefore}`;
        const timeout = setTimeout(() => {
          this.triggerWarrantyReminder(warrantyId, daysBefore, userId);
        }, timeUntilReminder);

        this.scheduledJobs.set(jobId, timeout);
      }
    });
  }

  clearWarrantyJobs(warrantyId: string) {
    const jobsToClear = Array.from(this.scheduledJobs.keys()).filter(key => key.startsWith(warrantyId));
    jobsToClear.forEach(jobId => {
      const timeout = this.scheduledJobs.get(jobId);
      if (timeout) {
        clearTimeout(timeout);
        this.scheduledJobs.delete(jobId);
      }
    });
  }

  private async triggerWarrantyReminder(warrantyId: string, daysBefore: number, userId: string) {
    try {
      // Get warranty details
      const stored = localStorage.getItem('warranties');
      if (!stored) return;

      const warranties = JSON.parse(stored);
      const warranty = warranties.find((w: any) => w.id === warrantyId && w.userId === userId);
      
      if (warranty) {
        // Send notification through service worker or direct API call
        await this.sendScheduledNotification(warranty, daysBefore);
      }
    } catch (error) {
      console.error('Error triggering scheduled reminder:', error);
    }
  }

  private async sendScheduledNotification(warranty: any, daysBefore: number) {
    const title = daysBefore === 0 
      ? 'Warranty Expires Today!' 
      : `Warranty Expires in ${daysBefore} Days`;
    
    const body = `Your ${warranty.productName} warranty from ${warranty.retailer} expires on ${warranty.expirationDate}`;

    if ('serviceWorker' in navigator && 'PushManager' in window) {
      try {
        const registration = await navigator.serviceWorker.ready;
        registration.showNotification(title, {
          body,
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          tag: `warranty-${warranty.id}`,
          requireInteraction: true,
          data: {
            warrantyId: warranty.id,
            type: 'warranty_reminder'
          }
        });
      } catch (error) {
        console.error('Error showing notification:', error);
      }
    }
  }

  scheduleDailyCheck() {
    // Schedule daily check at 9 AM
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(9, 0, 0, 0);

    const timeUntilCheck = tomorrow.getTime() - now.getTime();

    setTimeout(() => {
      this.performDailyCheck();
      // Schedule next day's check
      this.scheduleDailyCheck();
    }, timeUntilCheck);
  }

  private async performDailyCheck() {
    try {
      // This would typically call your Firebase Cloud Function
      // For now, we'll trigger local notification check
      const event = new CustomEvent('dailyWarrantyCheck');
      window.dispatchEvent(event);
    } catch (error) {
      console.error('Error in daily check:', error);
    }
  }

  rescheduleAllWarranties() {
    // Clear all existing jobs
    this.scheduledJobs.forEach(timeout => clearTimeout(timeout));
    this.scheduledJobs.clear();

    // Reschedule all warranties
    const stored = localStorage.getItem('warranties');
    if (stored) {
      const warranties = JSON.parse(stored);
      const preferences = JSON.parse(localStorage.getItem('notificationPrefs') || '{}');

      warranties.forEach((warranty: any) => {
        if (preferences[warranty.userId]) {
          this.scheduleWarrantyReminder(
            warranty.id,
            warranty.expirationDate,
            preferences[warranty.userId].reminderDays,
            warranty.userId
          );
        }
      });
    }
  }
}