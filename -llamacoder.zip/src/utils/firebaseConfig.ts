import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getFunctions } from 'firebase/functions';

const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "warranty-tracker.firebaseapp.com",
  projectId: "warranty-tracker",
  storageBucket: "warranty-tracker.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef",
  measurementId: "G-XXXXXXXX"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const functions = getFunctions(app);

// Cloud Functions for premium features
export const validatePurchase = functions.httpsCallable('validatePurchase');
export const processPayment = functions.httpsCallable('processPayment');
export const syncPremiumStatus = functions.httpsCallable('syncPremiumStatus');

export default app;