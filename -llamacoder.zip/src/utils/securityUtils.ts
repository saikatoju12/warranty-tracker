// Client-side security utilities for additional validation

export class SecurityValidator {
  // Validate email format
  static isValidEmail(email: string): boolean {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  }

  // Validate date format (YYYY-MM-DD)
  static isValidDate(date: string): boolean {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(date)) return false;
    
    const dateObj = new Date(date);
    return !isNaN(dateObj.getTime());
  }

  // Validate product name
  static isValidProductName(name: string): boolean {
    return name.length > 0 && name.length <= 200;
  }

  // Validate retailer name
  static isValidRetailer(retailer: string): boolean {
    return retailer.length > 0 && retailer.length <= 100;
  }

  // Validate warranty duration
  static isValidWarrantyDuration(duration: number): boolean {
    return [1, 2, 3, 5, 10].includes(duration);
  }

  // Validate warranty status
  static isValidWarrantyStatus(status: string): boolean {
    return ['active', 'expired', 'expiring_soon', 'cancelled'].includes(status);
  }

  // Validate notes
  static isValidNotes(notes: string): boolean {
    return notes.length <= 1000;
  }

  // Validate serial number
  static isValidSerialNumber(serial: string): boolean {
    return serial.length <= 100;
  }

  // Validate purchase amount
  static isValidPurchaseAmount(amount: number): boolean {
    return amount >= 0 && amount <= 1000000;
  }

  // Sanitize input to prevent XSS
  static sanitizeInput(input: string): string {
    return input
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/\//g, '&#x2F;');
  }

  // Validate file size for uploads
  static isValidFileSize(size: number, maxSize: number = 10 * 1024 * 1024): boolean {
    return size <= maxSize;
  }

  // Validate file type for images
  static isValidImageType(type: string): boolean {
    return ['image/jpeg', 'image/png', 'image/webp'].includes(type);
  }

  // Generate secure random ID
  static generateSecureId(): string {
    const array = new Uint8Array(16);
    crypto.getRandomValues(array);
    return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
  }

  // Validate notification preferences
  static isValidNotificationPreferences(prefs: any): boolean {
    const requiredKeys = ['pushEnabled', 'emailEnabled', 'reminderDays', 'reminderTime', 'expiredReminderEnabled'];
    return requiredKeys.every(key => key in prefs) &&
           typeof prefs.pushEnabled === 'boolean' &&
           typeof prefs.emailEnabled === 'boolean' &&
           Array.isArray(prefs.reminderDays) &&
           typeof prefs.reminderTime === 'string' &&
           typeof prefs.expiredReminderEnabled === 'boolean' &&
           prefs.reminderDays.length <= 10;
  }
}

// Rate limiting utility
export class RateLimiter {
  private static attempts = new Map<string, { count: number; resetTime: number }>();

  static isAllowed(identifier: string, maxAttempts: number = 5, windowMs: number = 60000): boolean {
    const now = Date.now();
    const attempts = this.attempts.get(identifier);

    if (!attempts || now > attempts.resetTime) {
      this.attempts.set(identifier, { count: 1, resetTime: now + windowMs });
      return true;
    }

    if (attempts.count >= maxAttempts) {
      return false;
    }

    attempts.count++;
    return true;
  }

  static cleanup(): void {
    const now = Date.now();
    for (const [key, value] of this.attempts.entries()) {
      if (now > value.resetTime) {
        this.attempts.delete(key);
      }
    }
  }
}