export function getDaysUntilExpiration(expirationDate: string): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiration = new Date(expirationDate);
  expiration.setHours(0, 0, 0, 0);
  
  const diffTime = expiration.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

export function getWarrantyStatus(expirationDate: string): {
  status: "expired" | "critical" | "warning" | "safe";
  label: string;
  color: string;
  bgColor: string;
} {
  const daysUntil = getDaysUntilExpiration(expirationDate);
  
  if (daysUntil < 0) {
    return {
      status: "expired",
      label: "Expired",
      color: "text-slate-600",
      bgColor: "bg-slate-100"
    };
  }
  
  if (daysUntil <= 7) {
    return {
      status: "critical",
      label: `${daysUntil} day${daysUntil === 1 ? "" : "s"} left`,
      color: "text-red-700",
      bgColor: "bg-red-100"
    };
  }
  
  if (daysUntil <= 30) {
    return {
      status: "warning",
      label: `${daysUntil} days left`,
      color: "text-amber-700",
      bgColor: "bg-amber-100"
    };
  }
  
  return {
    status: "safe",
    label: `${daysUntil} days left`,
    color: "text-green-700",
    bgColor: "bg-green-100"
  };
}

export function calculateExpirationDate(purchaseDate: string, durationYears: number): string {
  const purchase = new Date(purchaseDate);
  const expiration = new Date(purchase);
  expiration.setFullYear(expiration.getFullYear() + durationYears);
  return expiration.toISOString().split('T')[0];
}