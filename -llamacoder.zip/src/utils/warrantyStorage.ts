import { Warranty } from "../types/warranty";

export const warrantyStorage = {
  async getAll(): Promise<Warranty[]> {
    const stored = localStorage.getItem("warranties");
    return stored ? JSON.parse(stored) : [];
  },

  async save(warranty: Warranty): Promise<void> {
    const warranties = await this.getAll();
    warranties.push(warranty);
    localStorage.setItem("warranties", JSON.stringify(warranties));
  },

  async delete(id: string): Promise<void> {
    const warranties = await this.getAll();
    const filtered = warranties.filter(w => w.id !== id);
    localStorage.setItem("warranties", JSON.stringify(filtered));
  },

  async update(id: string, updates: Partial<Warranty>): Promise<void> {
    const warranties = await this.getAll();
    const index = warranties.findIndex(w => w.id === id);
    if (index !== -1) {
      warranties[index] = { ...warranties[index], ...updates };
      localStorage.setItem("warranties", JSON.stringify(warranties));
    }
  }
};