export interface OCRResult {
  purchaseDate?: string;
  storeName?: string;
  productKeywords?: string[];
  serialNumber?: string;
  productName?: string;
  confidence: number;
}

export class OCRProcessor {
  static extractDate(text: string): string | null {
    // Common date patterns
    const datePatterns = [
      /\b(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})\b/,
      /\b(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})\b/,
      /\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+\d{4}\b/i
    ];

    for (const pattern of datePatterns) {
      const match = text.match(pattern);
      if (match) {
        // Convert to YYYY-MM-DD format
        const date = new Date(match[0]);
        if (!isNaN(date.getTime())) {
          return date.toISOString().split('T')[0];
        }
      }
    }

    return null;
  }

  static extractStoreName(text: string): string | null {
    // Common store patterns
    const storePatterns = [
      /\b(Best Buy|Walmart|Target|Amazon|Home Depot|Lowe's|Costco|Sam's Club|Apple Store|Microsoft Store)\b/i,
      /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(Store|Shop|Mart|Market)\b/i
    ];

    for (const pattern of storePatterns) {
      const match = text.match(pattern);
      if (match) {
        return match[1];
      }
    }

    return null;
  }

  static extractProductKeywords(text: string): string[] {
    // Common product categories and brands
    const productKeywords = [
      // Electronics
      'iPhone', 'iPad', 'MacBook', 'Samsung', 'LG', 'Sony', 'Dell', 'HP', 'Lenovo',
      'TV', 'Laptop', 'Computer', 'Phone', 'Tablet', 'Headphones', 'Speaker',
      // Appliances
      'Refrigerator', 'Washer', 'Dryer', 'Dishwasher', 'Microwave', 'Oven',
      'Blender', 'Toaster', 'Coffee Maker',
      // Common descriptors
      'Pro', 'Max', 'Plus', 'Mini', 'Air', 'Smart', 'Wireless', 'Bluetooth',
      '128GB', '256GB', '512GB', '1TB', '4K', 'HD', 'OLED', 'LED'
    ];

    const found: string[] = [];
    const upperText = text.toUpperCase();

    productKeywords.forEach(keyword => {
      if (upperText.includes(keyword.toUpperCase())) {
        found.push(keyword);
      }
    });

    return found;
  }

  static extractSerialNumber(text: string): string | null {
    // Serial number patterns
    const serialPatterns = [
      /\bS\/N[:\s]+([A-Z0-9]{6,})\b/i,
      /\bSerial[:\s]+([A-Z0-9]{6,})\b/i,
      /\b([A-Z]{2,4}\d{6,})\b/,
      /\b(\d{10,})\b/
    ];

    for (const pattern of serialPatterns) {
      const match = text.match(pattern);
      if (match) {
        return match[1];
      }
    }

    return null;
  }

  static preprocessImage(imageData: string): Promise<string> {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (ctx) {
          canvas.width = img.width;
          canvas.height = img.height;
          
          // Apply image enhancements
          ctx.filter = 'contrast(1.5) brightness(1.2) saturate(1.1)';
          ctx.drawImage(img, 0, 0);
          
          // Convert to grayscale for better OCR
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const data = imageData.data;
          
          for (let i = 0; i < data.length; i += 4) {
            const gray = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
            data[i] = gray;
            data[i + 1] = gray;
            data[i + 2] = gray;
          }
          
          ctx.putImageData(imageData, 0, 0);
          resolve(canvas.toDataURL('image/jpeg', 0.95));
        }
      };
      img.src = imageData;
    });
  }

  static async processWithMLKit(imageData: string): Promise<OCRResult> {
    // Simulate Google ML Kit processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock text extraction
    const mockText = `
      BEST BUY
      Date: 01/15/2024
      Apple iPhone 15 Pro 128GB
      S/N: XYZ123ABC456
      Total: $999.99
    `;
    
    return {
      purchaseDate: this.extractDate(mockText),
      storeName: this.extractStoreName(mockText),
      productKeywords: this.extractProductKeywords(mockText),
      confidence: 0.85
    };
  }

  static async processWithOpenAI(imageData: string): Promise<OCRResult> {
    // Simulate OpenAI Vision API processing
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Mock advanced text extraction
    const mockText = `
      BEST BUY PURCHASE RECEIPT
      Transaction Date: January 15, 2024
      Store: Best Buy #1234
      
      Apple iPhone 15 Pro 128GB - Blue Titanium
      Serial Number: XYZ123ABC456789
      IMEI: 123456789012345
      
      Extended Warranty: 2 Years
      Total: $1,099.99
    `;
    
    return {
      purchaseDate: this.extractDate(mockText),
      storeName: this.extractStoreName(mockText),
      productKeywords: this.extractProductKeywords(mockText),
      serialNumber: this.extractSerialNumber(mockText),
      productName: 'Apple iPhone 15 Pro 128GB - Blue Titanium',
      confidence: 0.95
    };
  }
}